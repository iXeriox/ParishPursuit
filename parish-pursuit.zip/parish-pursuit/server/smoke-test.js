// End-to-end check over real sockets: two clients matchmake, fill with bots, ready up, play.
// Usage: start the server, then `node smoke-test.js [url]`
import { io } from 'socket.io-client';

const URL = process.argv[2] ?? 'http://localhost:3000';
const wait = ms => new Promise(r => setTimeout(r, ms));
const fail = msg => { console.error('FAIL:', msg); process.exit(1); };

function client(name) {
  const s = io(URL, { transports: ['websocket'] });
  const c = { s, name, lobby: null, start: null, snaps: 0, lastSnap: null, events: [], errors: [] };
  s.on('m', (type, d) => {
    if (type === 'lobby') c.lobby = d;
    if (type === 'start') c.start = d;
    if (type === 'snap') { c.snaps++; c.lastSnap = d; c.events.push(...d.events); }
    if (type === 'error') c.errors.push(d.message);
  });
  c.send = (t, d) => s.emit('m', t, d);
  return new Promise(res => s.on('connect', () => { c.send('hello', { name }); res(c); }));
}

const a = await client('Father Dave');
const b = await client('Wren');
a.send('quickPlay'); await wait(150);
b.send('quickPlay'); await wait(150);
if (!a.lobby || a.lobby.code !== b.lobby?.code) fail('quick play did not put both clients in one room');
console.log('✓ matchmaking: both in room', a.lobby.code, a.lobby.members.map(m => `${m.name}:${m.role}`).join(', '));

a.send('role', { role: 'dave' }); await wait(100);
if (!a.errors.length) fail('role uniqueness not enforced');
console.log('✓ role uniqueness:', a.errors.at(-1));

a.send('role', { role: 'seeker' });
a.send('fillBots'); await wait(150);
console.log('✓ fill bots →', a.lobby.members.length, 'players:', a.lobby.members.map(m => m.role).join(', '));
a.send('chat', { text: 'Hey everyone' }); await wait(100);
if (!b.lobby.chat.some(l => l.text === 'Hey everyone')) fail('chat not relayed');
console.log('✓ chat relayed');

a.send('ready', { ready: true }); b.send('ready', { ready: true });
await wait(300);
if (b.lobby.phase !== 'countdown') fail('countdown did not start, phase=' + b.lobby.phase);
console.log('✓ countdown', b.lobby.countdown);
await wait(4300);
if (!a.start || !b.start) fail('match did not start');
console.log('✓ match started, map', a.start.map.w + 'x' + a.start.map.h, 'role', a.start.role);

// drive the seeker client upward for a few seconds
const t0 = Date.now(), snaps0 = a.snaps;
let seq = 0;
while (Date.now() - t0 < 3000) {
  a.send('input', { mx: 0, my: -1, sprint: true, interact: false, aimX: 25, aimY: 2, ability: 0 });
  b.send('input', { mx: -1, my: 0, aimX: 30, aimY: 16, ability: ++seq % 30 === 0 ? seq : 0 });
  await wait(33);
}
const me = a.lastSnap.players.find(p => p.id === a.lastSnap.you.id);
const rate = (a.snaps - snaps0) / ((Date.now() - t0) / 1000);
console.log(`✓ ${rate.toFixed(1)} snapshots/s; seeker now at (${me.x}, ${me.y}), stamina ${a.lastSnap.you.stamina}`);
if (rate < 25) fail('snapshot rate too low');
if (me.y > 22) fail('input did not move the player');
const total = a.lastSnap.roster.length, seen = a.lastSnap.players.length;
console.log(`✓ visibility culling: seeker sees ${seen}/${total} players`);

// leaving mid-match → bot takeover, match continues for the other client
b.send('leave'); await wait(300);
const before = a.snaps; await wait(500);
if (a.snaps <= before) fail('match stalled after a player left');
const dave = a.lastSnap.roster.find(r => r.name.startsWith('Wren'));
console.log('✓ leaver taken over by bot:', dave?.name, dave?.isBot);

const res = await fetch(URL + '/health').then(r => r.json());
console.log('✓ /health', JSON.stringify(res));
console.log('\nALL GOOD');
process.exit(0);
