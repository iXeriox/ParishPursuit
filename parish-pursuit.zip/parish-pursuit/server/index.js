/*
 * Parish Pursuit — authoritative game server
 * Express (health + optional static hosting) + Socket.IO transport around the shared Hub.
 *
 *   PORT=3000 CORS_ORIGIN=http://localhost:5173 node index.js
 */
import express from 'express';
import http from 'node:http';
import path from 'node:path';
import { Server } from 'socket.io';
import { Hub, TICK_RATE } from '../client/parish-core.js';

const PORT = Number(process.env.PORT ?? 3000);
const CORS_ORIGIN = process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(',') : '*';
const STATIC_DIR = process.env.STATIC_DIR; // optional: serve your built Vue app from here

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: CORS_ORIGIN }, maxHttpBufferSize: 16 * 1024 });

const sockets = new Map();
const hub = new Hub((id, type, data) => {
  const s = sockets.get(id);
  if (!s) return;
  // snapshots are disposable: drop them rather than queue behind a slow connection
  if (type === 'snap') s.volatile.emit('m', type, data);
  else s.emit('m', type, data);
});

app.get('/health', (_req, res) => {
  res.json({ ok: true, players: sockets.size, rooms: hub.rooms.size, uptime: Math.round(process.uptime()) });
});
if (STATIC_DIR) {
  app.use(express.static(STATIC_DIR));
  app.get('*', (_req, res) => res.sendFile(path.resolve(STATIC_DIR, 'index.html')));
}

io.on('connection', socket => {
  sockets.set(socket.id, socket);
  hub.connect(socket.id);

  // simple token bucket: 60 msgs/s burst, refilled continuously
  let tokens = 60, last = Date.now();
  socket.on('m', (type, data) => {
    const now = Date.now();
    tokens = Math.min(60, tokens + (now - last) * 0.06);
    last = now;
    if (tokens < 1) return;
    tokens -= 1;
    try { hub.message(socket.id, type, data); }
    catch (err) { console.error('message error', type, err); }
  });

  socket.on('disconnect', () => {
    hub.disconnect(socket.id);
    sockets.delete(socket.id);
  });
});

let prev = performance.now();
setInterval(() => {
  const now = performance.now();
  const dt = Math.min(0.1, (now - prev) / 1000);
  prev = now;
  try { hub.tick(dt); } catch (err) { console.error('tick error', err); }
}, 1000 / TICK_RATE);

server.listen(PORT, () => console.log(`⛪ Parish Pursuit server on :${PORT} (tick ${TICK_RATE}Hz)`));
