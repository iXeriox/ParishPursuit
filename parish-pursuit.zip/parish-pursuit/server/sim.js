// Headless bot-vs-bot matches for balance tuning.
// Usage: node sim.js [games=20] [seekers=4] [hunters=2]
import { Game, CONFIG, HUNTER_ROLES } from '../client/parish-core.js';

const games = Number(process.argv[2] ?? 20);
const nSeek = Number(process.argv[3] ?? 4);
const nHunt = Math.min(3, Number(process.argv[4] ?? 2));
const dt = 1 / 30;

const tally = { seekers: 0, hunters: 0 };
const reasons = {};
let totalTime = 0, totalEvidence = 0, keyTaken = 0, lockdowns = 0;
const t0 = Date.now();

for (let g = 0; g < games; g++) {
  const roster = [];
  for (let i = 0; i < nSeek; i++) roster.push({ id: 's' + i, name: 'S' + i, role: 'seeker', isBot: true });
  for (let i = 0; i < nHunt; i++) roster.push({ id: 'h' + i, name: HUNTER_ROLES[i], role: HUNTER_ROLES[i], isBot: true });
  const game = new Game(roster, CONFIG);
  let sawLockdown = false;
  while (!game.over && game.time < CONFIG.matchSeconds + 120) {
    game.tick(dt);
    if (game.lockdown.active) sawLockdown = true;
    game.events.length = 0;
  }
  const o = game.over ?? { winner: 'none', reason: 'stalled', duration: game.time };
  tally[o.winner] = (tally[o.winner] ?? 0) + 1;
  reasons[o.reason] = (reasons[o.reason] ?? 0) + 1;
  totalTime += o.duration; totalEvidence += game.evidenceCount; keyTaken += game.keyTaken ? 1 : 0; lockdowns += sawLockdown ? 1 : 0;
}

console.log(`${games} games, ${nSeek} seekers vs ${nHunt} hunters (${((Date.now() - t0) / 1000).toFixed(1)}s wall)`);
console.log('wins:', tally);
console.log('reasons:', reasons);
console.log(`avg length ${(totalTime / games).toFixed(0)}s · avg evidence ${(totalEvidence / games).toFixed(1)} · key stolen ${keyTaken}/${games} · lockdown reached ${lockdowns}/${games}`);
