/*
 * Parish Pursuit — shared core
 * ------------------------------------------------------------------
 * Map, rules, abilities, bot AI and the lobby / matchmaking hub.
 * Zero dependencies. The Node server imports this file and runs it
 * authoritatively; the Vue component imports the same file to run
 * an offline "practice vs bots" match entirely in the browser.
 */

export const TICK_RATE = 30;

export const CONFIG = {
  matchSeconds: 480,          // until Morning Mass (hunters win on timeout)
  prepSeconds: 6,             // hunters frozen at the start
  lockdownSeconds: 45,        // police countdown after the call is placed
  evidenceNeeded: 6,          // of 8
  radius: 0.32,
  seekerSpeed: 3.6,
  sprintSpeed: 6.0,
  staminaMax: 3.5,
  staminaRegen: 0.7,
  hunterSpeed: { dave: 3.8, nun: 3.95, bishop: 3.65 },
  captureRange: 0.8,
  captureCooldown: 1,
  confessionSeconds: 2.5,      // hunter locked in place after a capture
  interactRange: 1.3,
  interactTimes: { key: 2, evidence: 2.5, rescue: 3, console: 3, cancel: 3 },
  consoleRelock: 8,
  cancelPenalty: 6,            // seconds added back when a hunter cuts the line
  trapStun: 2.5,
  revealSeconds: 4,
  rescueInvuln: 3,
  hunterVision: 7,
  seekerVision: 9,
  lanternSight: 11,
  countdownSeconds: 4,
  endScreenSeconds: 12,
  maxPlayers: 8,
  abilities: {
    dave:   { name: 'Corruption Spread', cooldown: 40, radius: 8, duration: 45 },
    nun:    { name: "The Nun's Pursuit", cooldown: 18, range: 8, speed: 16, pull: 2, root: 1 },
    bishop: { name: "The Bishop's Smoke", cooldown: 24, radius: 3.6, duration: 9, castRange: 7, slow: 0.6 },
  },
};

export const ROLES = {
  seeker: {
    team: 'seekers', label: 'Seeker',
    blurb: 'Steal the key, gather the evidence, call the police.',
    perks: ['Shift · Sprint (limited stamina)', 'Hold E · Steal / collect / rescue', 'Pull the lever to free jailed friends'],
  },
  dave: {
    team: 'hunters', label: 'Father Dave',
    blurb: 'Patient hunter who sabotages the evidence trail.',
    perks: ['Touch a seeker to jail them', 'Q · Corruption Spread: booby-trap nearby evidence', 'Tampered evidence stuns & reveals the thief'],
  },
  nun: {
    team: 'hunters', label: 'The Nun',
    blurb: 'Fastest hunter. Her rosary reels seekers in.',
    perks: ['Touch a seeker to jail them', "Q · The Nun's Pursuit: rosary tether pulls & roots", 'Aim with the mouse'],
  },
  bishop: {
    team: 'hunters', label: 'The Bishop',
    blurb: 'Slow, but his censer smoke blinds and bogs down seekers.',
    perks: ['Touch a seeker to jail them', "Q · The Bishop's Smoke: slowing, blinding cloud", 'Sees clearly through his own smoke'],
  },
};
export const HUNTER_ROLES = ['dave', 'nun', 'bishop'];

/* ------------------------------------------------------------------ */
/* Map                                                                 */
/* ------------------------------------------------------------------ */

const SOLID = new Set(['#', '=', 'X', 'A', 'T', '|']);

export function buildMapDef() {
  const W = 52, H = 36;
  const g = Array.from({ length: H }, () => Array(W).fill('#'));
  const fill = (x, y, w, h, ch = '.') => { for (let j = y; j < y + h; j++) for (let i = x; i < x + w; i++) g[j][i] = ch; };
  const put = (x, y, ch) => { g[y][x] = ch; };

  // rooms
  fill(2, 2, 11, 9);      // Vestry
  fill(16, 2, 20, 22);    // Main Nave
  fill(39, 2, 11, 9);     // Bell Tower
  fill(39, 13, 11, 11);   // Confessional
  fill(2, 13, 11, 11);    // Side Chapel
  fill(2, 27, 48, 7);     // Catacombs
  fill(22, 24, 8, 2);     // Narthex
  // passages
  fill(13, 5, 3, 2); fill(36, 5, 3, 2); fill(13, 17, 3, 2); fill(36, 17, 3, 2);
  fill(6, 11, 2, 2); fill(43, 11, 2, 2); fill(6, 24, 2, 3); fill(45, 24, 2, 3);

  // nave
  fill(24, 5, 4, 21, ',');                       // carpet aisle
  for (let y = 8; y <= 20; y += 2) { fill(18, y, 6, 1, '='); fill(28, y, 6, 1, '='); }
  fill(24, 3, 4, 1, 'A');                        // altar
  put(19, 4, '#'); put(32, 4, '#');              // pillars
  // vestry
  fill(6, 5, 3, 2, 'X'); fill(2, 2, 1, 3, 'X');
  // side chapel
  fill(3, 14, 3, 1, 'A');
  for (let y = 17; y <= 21; y += 2) fill(4, y, 7, 1, '=');
  // bell tower
  put(44, 2, 'T'); put(41, 5, '#'); put(47, 5, '#'); fill(40, 8, 2, 2, 'X');
  // confessional + holding cell
  fill(44, 14, 6, 1, '#'); fill(44, 22, 6, 1, '#'); fill(44, 15, 1, 7, '|');
  fill(39, 20, 2, 2, 'X');
  // catacombs
  for (const x of [10, 18, 26, 34, 42]) fill(x, 29, 2, 2, '#');
  fill(14, 27, 1, 5, '#'); fill(30, 29, 1, 5, '#'); fill(38, 27, 1, 5, '#');
  fill(20, 32, 3, 1, 'X'); fill(4, 28, 2, 1, 'X'); fill(46, 30, 2, 1, 'X');
  // crypt doors (locked until the Office Key is stolen)
  fill(6, 25, 2, 1, 'D'); fill(45, 25, 2, 1, 'D');

  const c = (x, y) => [x + 0.5, y + 0.5];
  return {
    w: W, h: H,
    tiles: g.map(r => r.join('')),
    rooms: [
      { name: 'Holding Cell', x: 45, y: 15, w: 5, h: 7, label: false },
      { name: 'Vestry', x: 2, y: 2, w: 11, h: 9 },
      { name: 'Main Nave', x: 16, y: 2, w: 20, h: 22 },
      { name: 'Bell Tower', x: 39, y: 2, w: 11, h: 9 },
      { name: 'Confessional', x: 39, y: 13, w: 11, h: 11 },
      { name: 'Side Chapel', x: 2, y: 13, w: 11, h: 11 },
      { name: 'Catacombs', x: 2, y: 27, w: 48, h: 7 },
      { name: 'Narthex', x: 22, y: 24, w: 8, h: 2 },
    ],
    candles: [[23, 3], [28, 3], [9, 2], [12, 9], [6, 14], [40, 3], [49, 13], [39, 23], [16, 12], [35, 12],
      [22, 25], [29, 25], [8, 27], [22, 33], [36, 27], [48, 33], [16, 33]].map(([x, y]) => c(x, y)),
    evidence: [[3, 9], [12, 14], [3, 22], [16, 2], [48, 9], [12, 32], [28, 28], [40, 32]].map(([x, y]) => c(x, y)),
    key: { x: 11.5, y: 3.5 },
    lever: { x: 42.5, y: 18.5 },
    console: { x: 44.5, y: 2.5 },
    jail: [[46, 16], [48, 16], [46, 18], [48, 18], [46, 20], [48, 20], [47, 15], [47, 19]].map(([x, y]) => c(x, y)),
    release: [[41, 17], [41, 19], [40, 18], [42, 16], [40, 16], [43, 19], [42, 20], [43, 17]].map(([x, y]) => c(x, y)),
    seekerSpawns: [[24, 22], [25, 22], [26, 22], [27, 22], [24, 24], [25, 24], [26, 24], [27, 24]].map(([x, y]) => c(x, y)),
    hunterSpawns: [[40, 14], [42, 14], [41, 16]].map(([x, y]) => c(x, y)),
  };
}

export function makeMap(def) {
  const m = { ...def, doorsOpen: false };
  m.tile = (x, y) => (x < 0 || y < 0 || x >= def.w || y >= def.h) ? '#' : def.tiles[y][x];
  m.isSolid = (x, y) => { const ch = m.tile(x, y); return ch === 'D' ? !m.doorsOpen : SOLID.has(ch); };
  m.blocksVision = (x, y) => { const ch = m.tile(x, y); return ch === '#' || (ch === 'D' && !m.doorsOpen); };
  m.roomAt = (x, y) => (def.rooms.find(r => x >= r.x && x < r.x + r.w && y >= r.y && y < r.y + r.h) || {}).name || '';
  return m;
}

/* ------------------------------------------------------------------ */
/* Geometry helpers (also used by the client renderer)                 */
/* ------------------------------------------------------------------ */

export const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);

/** Circle vs tile-grid movement with axis-separated sliding. */
export function moveEntity(map, e, dx, dy, r = CONFIG.radius) {
  if (dx) {
    e.x += dx;
    const y0 = Math.floor(e.y - r), y1 = Math.floor(e.y + r);
    if (dx > 0) { const tx = Math.floor(e.x + r); for (let y = y0; y <= y1; y++) if (map.isSolid(tx, y)) { e.x = tx - r - 0.001; break; } }
    else { const tx = Math.floor(e.x - r); for (let y = y0; y <= y1; y++) if (map.isSolid(tx, y)) { e.x = tx + 1 + r + 0.001; break; } }
  }
  if (dy) {
    e.y += dy;
    const x0 = Math.floor(e.x - r), x1 = Math.floor(e.x + r);
    if (dy > 0) { const ty = Math.floor(e.y + r); for (let x = x0; x <= x1; x++) if (map.isSolid(x, ty)) { e.y = ty - r - 0.001; break; } }
    else { const ty = Math.floor(e.y - r); for (let x = x0; x <= x1; x++) if (map.isSolid(x, ty)) { e.y = ty + 1 + r + 0.001; break; } }
  }
}

/** Grid DDA ray cast; returns distance to the first vision-blocking tile (capped at maxD). */
export function castRay(map, x0, y0, ang, maxD) {
  const dx = Math.cos(ang), dy = Math.sin(ang);
  let tx = Math.floor(x0), ty = Math.floor(y0);
  const stepX = dx > 0 ? 1 : -1, stepY = dy > 0 ? 1 : -1;
  const tDX = dx !== 0 ? Math.abs(1 / dx) : Infinity, tDY = dy !== 0 ? Math.abs(1 / dy) : Infinity;
  let tMX = dx > 0 ? (tx + 1 - x0) / dx : dx < 0 ? (x0 - tx) / -dx : Infinity;
  let tMY = dy > 0 ? (ty + 1 - y0) / dy : dy < 0 ? (y0 - ty) / -dy : Infinity;
  let t = 0;
  while (t < maxD) {
    if (tMX < tMY) { t = tMX; tMX += tDX; tx += stepX; } else { t = tMY; tMY += tDY; ty += stepY; }
    if (map.blocksVision(tx, ty)) return Math.min(t, maxD);
  }
  return maxD;
}

export function lineOfSight(map, x0, y0, x1, y1) {
  const d = Math.hypot(x1 - x0, y1 - y0);
  if (d < 0.01) return true;
  return castRay(map, x0, y0, Math.atan2(y1 - y0, x1 - x0), d) >= d - 1e-6;
}

/** Polygon (world coords) lit by a light/cone, clipped against walls. */
export function lightPolygon(map, x, y, dir, half, R, n) {
  const pts = [];
  const full = half >= Math.PI - 1e-3;
  if (!full) pts.push([x, y]);
  for (let i = 0; i <= n; i++) {
    const a = dir - half + (2 * half) * i / n;
    let d = castRay(map, x, y, a, R);
    if (d < R) d = Math.min(R, d + 0.35); // let light lick the wall face
    pts.push([x + Math.cos(a) * d, y + Math.sin(a) * d]);
  }
  return pts;
}

/** 4-connected BFS distance field from a goal tile (Int16, -1 = unreachable). */
export function distanceField(map, gx, gy) {
  const W = map.w, H = map.h;
  const d = new Int16Array(W * H).fill(-1);
  const q = new Int32Array(W * H);
  let head = 0, tail = 0;
  const s = gy * W + gx;
  d[s] = 0; q[tail++] = s;
  while (head < tail) {
    const cur = q[head++], cx = cur % W, cy = (cur / W) | 0, nd = d[cur] + 1;
    if (cx > 0 && d[cur - 1] < 0 && !map.isSolid(cx - 1, cy)) { d[cur - 1] = nd; q[tail++] = cur - 1; }
    if (cx < W - 1 && d[cur + 1] < 0 && !map.isSolid(cx + 1, cy)) { d[cur + 1] = nd; q[tail++] = cur + 1; }
    if (cy > 0 && d[cur - W] < 0 && !map.isSolid(cx, cy - 1)) { d[cur - W] = nd; q[tail++] = cur - W; }
    if (cy < H - 1 && d[cur + W] < 0 && !map.isSolid(cx, cy + 1)) { d[cur + W] = nd; q[tail++] = cur + W; }
  }
  return d;
}

function segPointDist(ax, ay, bx, by, px, py) {
  const vx = bx - ax, vy = by - ay, L = vx * vx + vy * vy;
  const t = L ? Math.max(0, Math.min(1, ((px - ax) * vx + (py - ay) * vy) / L)) : 0;
  return Math.hypot(ax + vx * t - px, ay + vy * t - py);
}

const DIRS8 = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];
const r2 = v => Math.round(v * 100) / 100;

/* ------------------------------------------------------------------ */
/* Game (one match)                                                    */
/* ------------------------------------------------------------------ */

export class Game {
  constructor(roster, cfg = CONFIG) {
    this.cfg = cfg;
    this.def = buildMapDef();
    this.map = makeMap(this.def);
    this.time = 0;
    this.timeLeft = cfg.matchSeconds;
    this.over = null;
    this.events = [];
    this.uid = 0;
    this.players = new Map();
    this.seekers = [];
    this.hunters = [];
    this.evidence = this.def.evidence.map((p, i) => ({ id: i, x: p[0], y: p[1], collected: false, tamperedUntil: 0 }));
    this.keyTaken = false;
    this.evidenceCount = 0;
    this.lockdown = { active: false, remaining: cfg.lockdownSeconds };
    this.consoleLockedUntil = 0;
    this.smokes = [];
    this.tethers = [];
    this.fieldCache = new Map();

    let si = 0, hi = 0;
    for (const r of roster) {
      const team = ROLES[r.role].team;
      const spawn = team === 'seekers' ? this.def.seekerSpawns[si % 8] : this.def.hunterSpawns[hi % 3];
      const p = {
        id: r.id, name: r.name, role: r.role, team, isBot: !!r.isBot,
        color: team === 'seekers' ? si : -1,
        x: spawn[0], y: spawn[1], dir: team === 'seekers' ? -Math.PI / 2 : Math.PI,
        state: 'free', stunUntil: 0, rootUntil: 0, revealedUntil: 0, invulnUntil: 0,
        stamina: cfg.staminaMax, exhausted: false, sprinting: false, moving: false,
        abilityReadyAt: 0, captureReadyAt: 0, abilitySeq: 0,
        interact: null,
        input: { mx: 0, my: 0, sprint: false, interact: false, aimX: null, aimY: null, ability: 0 },
        stats: { captures: 0, evidence: 0, rescues: 0 },
        bot: { thinkAt: 0, goal: null, avoid: new Set(), checked: new Set(), lastSeen: null, patrol: null, avoidResetAt: 30 },
      };
      if (team === 'seekers') { si++; this.seekers.push(p); } else { hi++; this.hunters.push(p); }
      this.players.set(r.id, p);
    }
  }

  emit(ev) { this.events.push(ev); }
  inSmoke(x, y) { return this.smokes.some(s => Math.hypot(s.x - x, s.y - y) < s.r); }
  smokeBetween(ax, ay, bx, by) { return this.smokes.some(s => segPointDist(ax, ay, bx, by, s.x, s.y) < s.r * 0.85); }
  jailedCount() { return this.seekers.filter(s => s.state === 'captured').length; }

  setInput(id, inp) {
    const p = this.players.get(id);
    if (!p || p.isBot || !inp || typeof inp !== 'object') return;
    const n = v => (typeof v === 'number' && Number.isFinite(v) ? v : 0);
    let mx = Math.max(-1, Math.min(1, n(inp.mx))), my = Math.max(-1, Math.min(1, n(inp.my)));
    const len = Math.hypot(mx, my);
    if (len > 1) { mx /= len; my /= len; }
    const fin = v => (typeof v === 'number' && Number.isFinite(v) ? v : null);
    p.input = {
      mx, my, sprint: !!inp.sprint, interact: !!inp.interact,
      aimX: fin(inp.aimX), aimY: fin(inp.aimY),
      ability: Math.max(p.input.ability, Math.floor(n(inp.ability))),
    };
  }

  setBot(id, on) {
    const p = this.players.get(id);
    if (!p) return;
    p.isBot = on;
    p.abilitySeq = p.input.ability;
    p.input = { mx: 0, my: 0, sprint: false, interact: false, aimX: null, aimY: null, ability: p.input.ability };
  }

  tick(dt) {
    if (this.over) return;
    const c = this.cfg;
    this.time += dt;
    this.timeLeft = Math.max(0, this.timeLeft - dt);
    const prep = this.time < c.prepSeconds;

    for (const p of this.players.values()) if (p.isBot) this.botThink(p);
    for (const p of this.players.values()) this.updateMovement(p, dt, prep);
    for (const p of this.players.values()) {
      if (p.input.ability > p.abilitySeq) { p.abilitySeq = p.input.ability; if (!prep) this.useAbility(p); }
    }
    for (const p of this.players.values()) this.updateInteraction(p, dt);
    this.updateTethers(dt);
    if (!prep) this.updateCaptures();
    this.smokes = this.smokes.filter(s => s.until > this.time);

    if (this.lockdown.active) {
      this.lockdown.remaining -= dt;
      if (this.lockdown.remaining <= 0) return this.finish('seekers', "The police stormed the parish. The Cardinal's secret is out.");
    }
    if (this.seekers.length && this.seekers.every(s => s.state === 'captured')) return this.finish('hunters', 'Every seeker is locked in the holding cell.');
    if (!this.seekers.length || !this.hunters.length) return this.finish(this.seekers.length ? 'seekers' : 'hunters', 'The other side abandoned the parish.');
    if (this.timeLeft <= 0 && !this.lockdown.active) return this.finish('hunters', 'Morning Mass began. The secret stays buried.');
  }

  updateMovement(p, dt, prep) {
    const c = this.cfg, inp = p.input;
    if (inp.aimX != null && inp.aimY != null && (inp.aimX !== p.x || inp.aimY !== p.y)) p.dir = Math.atan2(inp.aimY - p.y, inp.aimX - p.x);
    let mx = inp.mx, my = inp.my;
    if ((p.team === 'hunters' && prep) || p.stunUntil > this.time || p.rootUntil > this.time) mx = my = 0;
    p.moving = Math.hypot(mx, my) > 0.05;
    let speed;
    if (p.team === 'seekers') {
      if (p.stamina <= 0) p.exhausted = true;
      if (p.exhausted && p.stamina >= 1) p.exhausted = false;
      const sprint = inp.sprint && p.moving && !p.exhausted && p.state === 'free';
      p.sprinting = sprint;
      p.stamina = sprint ? Math.max(0, p.stamina - dt) : Math.min(c.staminaMax, p.stamina + dt * c.staminaRegen);
      speed = sprint ? c.sprintSpeed : c.seekerSpeed;
      if (this.inSmoke(p.x, p.y)) speed *= c.abilities.bishop.slow;
    } else speed = c.hunterSpeed[p.role];
    if (p.moving) {
      if (inp.aimX == null) p.dir = Math.atan2(my, mx);
      moveEntity(this.map, p, mx * speed * dt, my * speed * dt);
    }
  }

  useAbility(p) {
    if (p.team !== 'hunters' || p.abilityReadyAt > this.time || p.stunUntil > this.time) return;
    const a = this.cfg.abilities[p.role];
    const aimX = p.input.aimX ?? p.x + Math.cos(p.dir) * 3, aimY = p.input.aimY ?? p.y + Math.sin(p.dir) * 3;
    if (p.role === 'dave') {
      let n = 0;
      for (const e of this.evidence) if (!e.collected && dist(e, p) <= a.radius) { e.tamperedUntil = this.time + a.duration; n++; }
      if (!n) { this.emit({ type: 'fizzle', to: p.id }); return; }
      this.emit({ type: 'corrupt', vis: 'hunters', n });
    } else if (p.role === 'nun') {
      const ang = Math.atan2(aimY - p.y, aimX - p.x);
      this.tethers.push({ owner: p.id, x: p.x, y: p.y, vx: Math.cos(ang) * a.speed, vy: Math.sin(ang) * a.speed, left: a.range, doneAt: 0, hit: null });
    } else if (p.role === 'bishop') {
      let dx = aimX - p.x, dy = aimY - p.y;
      const d = Math.hypot(dx, dy);
      if (d > a.castRange) { dx *= a.castRange / d; dy *= a.castRange / d; }
      let x = p.x + dx, y = p.y + dy;
      if (this.map.isSolid(Math.floor(x), Math.floor(y)) || !lineOfSight(this.map, p.x, p.y, x, y)) { x = p.x; y = p.y; }
      this.smokes.push({ id: ++this.uid, x, y, r: a.radius, until: this.time + a.duration });
      this.emit({ type: 'smoke', vis: 'all' });
    }
    p.abilityReadyAt = this.time + a.cooldown;
  }

  findInteraction(p) {
    if (p.state !== 'free') return null;
    const c = this.cfg, R = c.interactRange, d = this.def;
    const near = (x, y, extra = 0) => Math.hypot(p.x - x, p.y - y) <= R + extra;
    if (p.team === 'seekers') {
      if (!this.keyTaken && near(d.key.x, d.key.y)) return { key: 'key', kind: 'key', dur: c.interactTimes.key };
      let best = null, bd = Infinity;
      for (const e of this.evidence) {
        if (e.collected) continue;
        const dd = Math.hypot(p.x - e.x, p.y - e.y);
        if (dd <= R && dd < bd) { bd = dd; best = e; }
      }
      if (best) return { key: 'ev' + best.id, kind: 'evidence', id: best.id, dur: c.interactTimes.evidence };
      if (near(d.lever.x, d.lever.y) && this.jailedCount() > 0) return { key: 'lever', kind: 'rescue', dur: c.interactTimes.rescue };
      if (near(d.console.x, d.console.y, 0.5) && this.evidenceCount >= c.evidenceNeeded && !this.lockdown.active && this.time >= this.consoleLockedUntil) {
        return { key: 'console', kind: 'console', dur: c.interactTimes.console };
      }
    } else if (this.lockdown.active && near(d.console.x, d.console.y, 0.5)) {
      return { key: 'cancel', kind: 'cancel', dur: c.interactTimes.cancel };
    }
    return null;
  }

  updateInteraction(p, dt) {
    const inp = p.input;
    if (!inp.interact || p.moving || p.state !== 'free' || p.stunUntil > this.time || p.rootUntil > this.time) { p.interact = null; return; }
    const target = this.findInteraction(p);
    if (!target) { p.interact = null; return; }
    if (!p.interact || p.interact.key !== target.key) p.interact = { ...target, progress: 0 };
    p.interact.progress += dt;
    if (p.interact.progress >= p.interact.dur) {
      const t = p.interact;
      p.interact = null;
      this.completeInteraction(p, t);
    }
  }

  completeInteraction(p, t) {
    const c = this.cfg;
    switch (t.kind) {
      case 'key':
        this.keyTaken = true;
        this.map.doorsOpen = true;
        this.fieldCache.clear();
        this.emit({ type: 'key', vis: 'all', who: p.name });
        break;
      case 'evidence': {
        const e = this.evidence[t.id];
        if (e.collected) break;
        if (e.tamperedUntil > this.time) {
          e.tamperedUntil = 0;
          p.stunUntil = this.time + c.trapStun;
          p.revealedUntil = this.time + c.revealSeconds;
          this.emit({ type: 'trap', vis: 'all', who: p.name });
        } else {
          e.collected = true;
          this.evidenceCount++;
          p.stats.evidence++;
          this.emit({ type: 'evidence', vis: 'all', who: p.name, n: this.evidenceCount, need: c.evidenceNeeded });
          if (this.evidenceCount === c.evidenceNeeded) this.emit({ type: 'consoleReady', vis: 'all' });
        }
        break;
      }
      case 'rescue': {
        const jailed = this.seekers.filter(s => s.state === 'captured');
        jailed.forEach((s, i) => {
          const r = this.def.release[i % this.def.release.length];
          s.state = 'free'; s.x = r[0]; s.y = r[1];
          s.invulnUntil = this.time + c.rescueInvuln; s.stunUntil = 0; s.rootUntil = 0;
        });
        p.stats.rescues += jailed.length;
        this.emit({ type: 'rescue', vis: 'all', who: p.name, n: jailed.length });
        break;
      }
      case 'console':
        this.lockdown = { active: true, remaining: this.lockdown.remaining };
        this.emit({ type: 'lockdownStart', vis: 'all', who: p.name });
        break;
      case 'cancel':
        this.lockdown = { active: false, remaining: Math.min(c.lockdownSeconds, this.lockdown.remaining + c.cancelPenalty) };
        this.consoleLockedUntil = this.time + c.consoleRelock;
        this.emit({ type: 'lockdownCancel', vis: 'all', who: p.name });
        break;
    }
  }

  updateTethers(dt) {
    const c = this.cfg, a = c.abilities.nun;
    for (const t of this.tethers) {
      if (t.doneAt) continue;
      const owner = this.players.get(t.owner);
      for (let i = 0; i < 3 && !t.doneAt; i++) {
        const sx = t.vx * dt / 3, sy = t.vy * dt / 3;
        t.x += sx; t.y += sy; t.left -= Math.hypot(sx, sy);
        if (this.map.blocksVision(Math.floor(t.x), Math.floor(t.y)) || t.left <= 0) { t.doneAt = this.time; break; }
        for (const s of this.seekers) {
          if (s.state !== 'free' || s.invulnUntil > this.time) continue;
          if (Math.hypot(s.x - t.x, s.y - t.y) < 0.55) {
            t.doneAt = this.time; t.hit = s.id;
            s.rootUntil = this.time + a.root;
            s.revealedUntil = this.time + c.revealSeconds;
            s.interact = null;
            const ang = Math.atan2(owner.y - s.y, owner.x - s.x);
            const pull = Math.min(a.pull, Math.max(0, dist(owner, s) - 1.1));
            for (let k = 0; k < 10; k++) moveEntity(this.map, s, Math.cos(ang) * pull / 10, Math.sin(ang) * pull / 10);
            this.emit({ type: 'tether', vis: 'all', who: s.name });
            break;
          }
        }
      }
    }
    this.tethers = this.tethers.filter(t => !t.doneAt || this.time - t.doneAt < 0.35);
  }

  updateCaptures() {
    const c = this.cfg;
    for (const h of this.hunters) {
      if (h.captureReadyAt > this.time || h.stunUntil > this.time) continue;
      for (const s of this.seekers) {
        if (s.state !== 'free' || s.invulnUntil > this.time) continue;
        if (dist(h, s) <= c.captureRange) {
          const spot = this.def.jail[this.jailedCount() % this.def.jail.length];
          s.state = 'captured'; s.x = spot[0]; s.y = spot[1];
          s.interact = null; s.sprinting = false; s.rootUntil = 0; s.stunUntil = 0;
          h.captureReadyAt = this.time + c.captureCooldown;
          h.stunUntil = this.time + c.confessionSeconds;   // "Forced Confession": hunter is busy for a moment
          h.stats.captures++;
          this.emit({ type: 'capture', vis: 'all', who: s.name, by: h.name, whoId: s.id });
          break;
        }
      }
    }
  }

  canSee(v, p) {
    const c = this.cfg;
    if (v.team === p.team || p.state === 'captured') return true;
    const d = dist(v, p);
    if (v.team === 'hunters') {
      if (p.revealedUntil > this.time) return true;
      return d <= c.hunterVision + 1 && lineOfSight(this.map, v.x, v.y, p.x, p.y);
    }
    const range = this.inSmoke(v.x, v.y) ? 3 : c.lanternSight;
    return d <= range && lineOfSight(this.map, v.x, v.y, p.x, p.y) && !this.smokeBetween(v.x, v.y, p.x, p.y);
  }

  finish(winner, reason) {
    this.over = {
      winner, reason, duration: Math.round(this.time),
      evidence: this.evidenceCount, need: this.cfg.evidenceNeeded,
      players: [...this.players.values()].map(p => ({ id: p.id, name: p.name, role: p.role, team: p.team, state: p.state, ...p.stats })),
    };
  }

  snapshotFor(id) {
    const c = this.cfg, v = this.players.get(id);
    if (!v) return null;
    const T = this.time;
    const players = [];
    for (const p of this.players.values()) {
      if (p !== v && !this.canSee(v, p)) continue;
      players.push({
        id: p.id, x: r2(p.x), y: r2(p.y), dir: r2(p.dir), role: p.role, team: p.team, name: p.name, color: p.color,
        state: p.state, moving: p.moving, sprinting: p.sprinting,
        stunned: p.stunUntil > T, rooted: p.rootUntil > T, revealed: p.revealedUntil > T, invuln: p.invulnUntil > T,
      });
    }
    const a = c.abilities[v.role];
    return {
      t: r2(T),
      timeLeft: Math.ceil(this.timeLeft),
      prep: Math.max(0, Math.ceil(c.prepSeconds - T)),
      you: {
        id, role: v.role, team: v.team, state: v.state,
        stamina: r2(v.stamina / c.staminaMax), exhausted: v.exhausted,
        abilityCd: a ? r2(Math.max(0, v.abilityReadyAt - T)) : 0, abilityMax: a ? a.cooldown : 0,
        interact: v.interact ? { kind: v.interact.kind, p: r2(v.interact.progress / v.interact.dur) } : null,
        prompt: this.findInteraction(v)?.kind ?? null,
        inSmoke: this.inSmoke(v.x, v.y), stunned: v.stunUntil > T, rooted: v.rootUntil > T,
      },
      players,
      roster: [...this.players.values()].map(p => ({ id: p.id, name: p.name, role: p.role, team: p.team, color: p.color, state: p.state, isBot: p.isBot })),
      evidence: this.evidence.filter(e => !e.collected).map(e => ({ id: e.id, x: e.x, y: e.y, tampered: e.tamperedUntil > T })),
      obj: {
        key: this.keyTaken, found: this.evidenceCount, need: c.evidenceNeeded, total: this.evidence.length,
        lockdown: this.lockdown.active ? Math.ceil(this.lockdown.remaining) : null,
        consoleReady: this.evidenceCount >= c.evidenceNeeded && T >= this.consoleLockedUntil,
        jailed: this.jailedCount(), seekers: this.seekers.length,
      },
      doors: this.map.doorsOpen,
      smokes: this.smokes.map(s => ({ id: s.id, x: r2(s.x), y: r2(s.y), r: s.r, life: r2(s.until - T) })),
      tethers: this.tethers.map(t => { const o = this.players.get(t.owner); return { ox: r2(o.x), oy: r2(o.y), x: r2(t.x), y: r2(t.y), hit: !!t.hit }; }),
      events: this.events.filter(e => (e.to ? e.to === id : (e.vis === 'all' || e.vis === v.team))),
    };
  }

  /* ---------------------------- bots ---------------------------- */

  field(gx, gy) {
    gx = Math.max(0, Math.min(this.def.w - 1, gx)); gy = Math.max(0, Math.min(this.def.h - 1, gy));
    const key = gx + ',' + gy;
    const f = this.fieldCache.get(key);
    if (f) return f;
    const d = distanceField(this.map, gx, gy);
    this.fieldCache.set(key, d);
    if (this.fieldCache.size > 120) this.fieldCache.delete(this.fieldCache.keys().next().value);
    return d;
  }

  steer(p, d, flee = false) {
    const W = this.def.w, cx = Math.floor(p.x), cy = Math.floor(p.y);
    const here = d[cy * W + cx];
    let best = null, bv = flee ? -Infinity : (here >= 0 ? here : Infinity);
    for (const [dx, dy] of DIRS8) {
      const nx = cx + dx, ny = cy + dy;
      if (this.map.isSolid(nx, ny)) continue;
      if (dx && dy && (this.map.isSolid(cx + dx, cy) || this.map.isSolid(cx, cy + dy))) continue;
      const v = d[ny * W + nx];
      if (v < 0) continue;
      if (flee ? v > bv : v < bv) { bv = v; best = [nx, ny]; }
    }
    if (!best) return null;
    const tx = best[0] + 0.5 - p.x, ty = best[1] + 0.5 - p.y, L = Math.hypot(tx, ty) || 1;
    return { mx: tx / L, my: ty / L };
  }

  goTo(p, x, y) {
    const s = this.steer(p, this.field(Math.floor(x), Math.floor(y)));
    if (s) { p.input.mx = s.mx; p.input.my = s.my; }
    else { const d = Math.hypot(x - p.x, y - p.y) || 1; p.input.mx = (x - p.x) / d; p.input.my = (y - p.y) / d; }
  }

  aim(p, x, y) { p.input.aimX = x; p.input.aimY = y; }
  aimAlong(p) { if (p.input.mx || p.input.my) this.aim(p, p.x + p.input.mx * 4, p.y + p.input.my * 4); }

  botThink(p) {
    const inp = p.input;
    inp.mx = 0; inp.my = 0; inp.interact = false; inp.sprint = false;
    if (p.team === 'seekers') this.botSeeker(p); else this.botHunter(p);
  }

  randomWaypoint() {
    const pts = [...this.def.evidence, ...this.def.rooms.filter(r => r.label !== false).map(r => [r.x + r.w / 2, r.y + r.h / 2])];
    for (let i = 0; i < 10; i++) {
      const [x, y] = pts[(Math.random() * pts.length) | 0];
      if (!this.map.isSolid(Math.floor(x), Math.floor(y))) return { x, y };
    }
    return { x: 25.5, y: 22.5 };
  }

  botSeeker(p) {
    const c = this.cfg, b = p.bot, inp = p.input;
    if (p.state !== 'free') return;
    if (this.time > b.avoidResetAt) { b.avoid.clear(); b.checked.clear(); b.avoidResetAt = this.time + 30; }

    let threat = null, td = Infinity;
    for (const h of this.hunters) {
      const d = dist(h, p);
      if (d < 8.5 && d < td && this.time >= c.prepSeconds - 1 && this.canSee(p, h) && lineOfSight(this.map, p.x, p.y, h.x, h.y)) { td = d; threat = h; }
    }
    const nearlyDone = p.interact && p.interact.progress > p.interact.dur * 0.7 && td > 3;
    if (threat && !nearlyDone) {
      if (!b.escape || this.time >= b.escapeAt || Math.hypot(p.x - b.escape.x, p.y - b.escape.y) < 1.5) {
        b.escape = this.escapePoint(p, threat);
        b.escapeAt = this.time + 0.6;
      }
      if (b.escape) this.goTo(p, b.escape.x, b.escape.y);
      else { const s = this.steer(p, this.field(Math.floor(threat.x), Math.floor(threat.y)), true); if (s) { inp.mx = s.mx; inp.my = s.my; } }
      inp.sprint = td < 6;
      this.aimAlong(p);
      b.goal = null;
      return;
    }

    if (!b.goal || this.time >= b.thinkAt) { b.goal = this.pickSeekerGoal(p); b.thinkAt = this.time + 0.5 + Math.random() * 0.3; }
    const g = b.goal;
    if (!g) return;
    const d = Math.hypot(p.x - g.x, p.y - g.y);
    if (g.kind === 'evidence' && d < 3 && !b.checked.has(g.id)) {
      b.checked.add(g.id);
      const e = this.evidence[g.id];
      if (e.tamperedUntil > this.time && Math.random() < 0.55) { b.avoid.add(g.id); b.goal = null; return; }
    }
    if (d <= g.reach) {
      if (g.interact) { inp.interact = true; this.aim(p, g.x, g.y); }
      else b.goal = null;
      return;
    }
    this.goTo(p, g.x, g.y);
    inp.sprint = g.urgent && p.stamina > 0.6 * c.staminaMax;
    this.aimAlong(p);
  }

  /** Waypoint the seeker reaches well before the hunter does (avoids fleeing into dead ends). */
  escapePoint(p, threat) {
    const W = this.def.w;
    const mine = this.field(Math.floor(p.x), Math.floor(p.y));
    const theirs = this.field(Math.floor(threat.x), Math.floor(threat.y));
    if (!this.escapeSpots) {
      const spots = [];
      for (let y = 1; y < this.def.h - 1; y += 2) for (let x = 1; x < W - 1; x += 2) if (!this.map.isSolid(x, y)) {
        let open = 0;
        for (const [dx, dy] of DIRS8) if (!this.map.isSolid(x + dx, y + dy)) open++;
        if (open >= 7) spots.push([x, y]);
      }
      this.escapeSpots = spots;
    }
    let best = null, bs = -Infinity;
    for (const [x, y] of this.escapeSpots) {
      const a = mine[y * W + x], h = theirs[y * W + x];
      if (a < 0 || h < 0 || a < 4 || a > 22) continue;
      // must be closer for me, and the first step must not head toward the hunter
      const dirX = x - p.x, dirY = y - p.y, L = Math.hypot(dirX, dirY) || 1;
      const toward = ((threat.x - p.x) * dirX + (threat.y - p.y) * dirY) / (L * (dist(p, threat) || 1));
      const score = (h - a) * 1.4 + Math.min(h, 18) * 0.4 - toward * 6 + Math.random() * 1.5;
      if (score > bs) { bs = score; best = { x: x + 0.5, y: y + 0.5 }; }
    }
    return best;
  }

  pickSeekerGoal(p) {
    const c = this.cfg, d = this.def;
    const free = this.seekers.filter(s => s.state === 'free');
    if (this.jailedCount() > 0) {
      const closest = free.reduce((a, s) => (!a || dist(s, d.lever) < dist(a, d.lever) ? s : a), null);
      if (closest === p) return { kind: 'rescue', x: d.lever.x, y: d.lever.y, reach: 1.1, interact: true, urgent: true };
    }
    if (this.evidenceCount >= c.evidenceNeeded) {
      if (!this.lockdown.active && this.time >= this.consoleLockedUntil) return { kind: 'console', x: d.console.x, y: d.console.y, reach: 1.5, interact: true, urgent: true };
      if (this.lockdown.active) { const far = this.hunters.reduce((a, h) => (!a || dist(h, p) < dist(a, p) ? h : a), null); return { kind: 'hide', ...(far && this.escapePoint(p, far) || this.randomWaypoint()), reach: 1.2 }; }
    }
    if (!this.keyTaken && (p.color % 2 === 0 || free.length === 1)) return { kind: 'key', x: d.key.x, y: d.key.y, reach: 1.1, interact: true };
    const field = this.field(Math.floor(p.x), Math.floor(p.y));
    const claimed = new Set(this.seekers.filter(s => s !== p && s.bot.goal?.kind === 'evidence').map(s => s.bot.goal.id));
    let best = null, bd = Infinity;
    for (const e of this.evidence) {
      if (e.collected || p.bot.avoid.has(e.id)) continue;
      let v = field[Math.floor(e.y) * d.w + Math.floor(e.x)];
      if (v < 0) continue;
      if (claimed.has(e.id)) v += 25;
      if (v < bd) { bd = v; best = e; }
    }
    if (best) return { kind: 'evidence', id: best.id, x: best.x, y: best.y, reach: 1.1, interact: true };
    if (!this.keyTaken) return { kind: 'key', x: d.key.x, y: d.key.y, reach: 1.1, interact: true };
    return { kind: 'wander', ...this.randomWaypoint(), reach: 1.2 };
  }

  botHunter(p) {
    const c = this.cfg, b = p.bot, inp = p.input, d = this.def;
    if (this.time < c.prepSeconds) return;
    let tgt = null, td = Infinity;
    for (const s of this.seekers) {
      if (s.state !== 'free' || s.invulnUntil > this.time || !this.canSee(p, s)) continue;
      const dd = dist(p, s);
      if (dd < td) { td = dd; tgt = s; }
    }
    if (tgt) b.lastSeen = { x: tgt.x, y: tgt.y, t: this.time };

    if (this.lockdown.active && (!tgt || td > 3.5)) {
      if (Math.hypot(p.x - d.console.x, p.y - d.console.y) <= 1.6) { inp.interact = true; this.aim(p, d.console.x, d.console.y); return; }
      this.goTo(p, d.console.x, d.console.y); this.aimAlong(p); return;
    }
    if (tgt) {
      if (td < 1.6) { inp.mx = (tgt.x - p.x) / td; inp.my = (tgt.y - p.y) / td; }
      else this.goTo(p, tgt.x, tgt.y);
      this.aim(p, tgt.x, tgt.y);
      const ready = p.abilityReadyAt <= this.time;
      if (ready && p.role === 'nun' && td > 1.8 && td < 7.5 && lineOfSight(this.map, p.x, p.y, tgt.x, tgt.y) && Math.random() < 0.06) inp.ability++;
      if (ready && p.role === 'bishop' && td < 5.5 && Math.random() < 0.04) inp.ability++;
      return;
    }
    if (p.role === 'dave' && p.abilityReadyAt <= this.time && Math.random() < 0.03 &&
        this.evidence.some(e => !e.collected && e.tamperedUntil <= this.time && dist(e, p) < c.abilities.dave.radius - 1)) inp.ability++;
    if (b.lastSeen && this.time - b.lastSeen.t < 6) {
      if (Math.hypot(p.x - b.lastSeen.x, p.y - b.lastSeen.y) < 1) b.lastSeen = null;
      else { this.goTo(p, b.lastSeen.x, b.lastSeen.y); this.aimAlong(p); return; }
    }
    if (!b.patrol || Math.hypot(p.x - b.patrol.x, p.y - b.patrol.y) < 1.5 || this.time > b.patrol.until) {
      let w;
      const r = Math.random();
      if (this.jailedCount() > 0 && r < 0.3) w = { x: d.lever.x - 1, y: d.lever.y };
      else if (this.evidenceCount >= c.evidenceNeeded - 1 && r < 0.5) w = { x: d.console.x, y: d.console.y + 2 };
      else {
        const left = this.evidence.filter(e => !e.collected);
        w = left.length && r < 0.75 ? left[(Math.random() * left.length) | 0] : this.randomWaypoint();
      }
      b.patrol = { x: w.x, y: w.y, until: this.time + 20 };
    }
    this.goTo(p, b.patrol.x, b.patrol.y);
    this.aimAlong(p);
  }
}

/* ------------------------------------------------------------------ */
/* Lobby + matchmaking                                                 */
/* ------------------------------------------------------------------ */

const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
const BOT_NAMES = ['Ash', 'Rowan', 'Wren', 'Milo', 'Ivy', 'Jude', 'Sky', 'Finn', 'Nell', 'Ozzy'];
const cleanName = n => String(n ?? '').replace(/[^\w \-'.]/g, '').trim().slice(0, 16) || 'Player';
const teamOf = role => ROLES[role]?.team;

class Room {
  constructor(hub, code, isPublic) {
    this.hub = hub; this.cfg = hub.cfg; this.code = code; this.isPublic = isPublic;
    this.members = new Map(); this.hostId = null; this.phase = 'lobby';
    this.chat = []; this.chatSeq = 0; this.countdown = 0; this.game = null; this.endTimer = 0;
  }
  list() { return [...this.members.values()]; }
  humans() { return this.list().filter(m => !m.isBot); }
  hasHumans() { return this.humans().length > 0; }

  freeHunterRole() { return HUNTER_ROLES.find(r => !this.list().some(m => m.role === r)); }

  add(c) {
    const hasHunter = this.list().some(m => teamOf(m.role) === 'hunters');
    const role = !hasHunter && this.members.size >= 1 ? (this.freeHunterRole() || 'seeker') : 'seeker';
    this.members.set(c.id, { id: c.id, name: c.name, role, ready: false, isBot: false });
    if (!this.hostId) this.hostId = c.id;
    this.system(`Player '${c.name}' joined`);
  }

  remove(id) {
    const m = this.members.get(id);
    if (!m) return;
    if (this.game && !this.game.over && this.game.players.has(id)) {
      this.game.setBot(id, true);
      m.isBot = true; m.left = true; m.name += ' (bot)';
    } else this.members.delete(id);
    if (this.hostId === id) this.hostId = this.humans()[0]?.id ?? null;
    this.system(`Player '${m.name.replace(' (bot)', '')}' left`);
  }

  addBot(role) {
    if (this.members.size >= this.cfg.maxPlayers) return false;
    if (!role) role = this.list().some(m => teamOf(m.role) === 'hunters') ? 'seeker' : (this.freeHunterRole() || 'seeker');
    const used = new Set(this.list().map(m => m.name));
    const name = role === 'seeker'
      ? (BOT_NAMES.find(n => !used.has(n + ' (bot)')) || 'Seeker') + ' (bot)'
      : ROLES[role].label + ' (bot)';
    const id = 'bot-' + (++this.hub.botSeq);
    this.members.set(id, { id, name, role, ready: true, isBot: true });
    return true;
  }

  fillBots() {
    const target = Math.min(7, this.cfg.maxPlayers);
    while (this.list().filter(m => teamOf(m.role) === 'hunters').length < 2 && this.freeHunterRole() && this.members.size < target) this.addBot(this.freeHunterRole());
    while (this.members.size < target) if (!this.addBot('seeker')) break;
  }

  validate() {
    const l = this.list();
    const h = l.filter(m => teamOf(m.role) === 'hunters').length, s = l.length - h;
    if (l.length < 2) return { ok: false, reason: 'Need at least 2 players (add a bot)' };
    if (!h) return { ok: false, reason: 'Need at least one hunter' };
    if (!s) return { ok: false, reason: 'Need at least one seeker' };
    if (s < h) return { ok: false, reason: 'Need at least as many seekers as hunters' };
    return { ok: true, reason: '' };
  }

  handle(c, type, data) {
    const m = this.members.get(c.id);
    if (!m) return;
    if (type === 'input') { if (this.phase === 'playing' && this.game) this.game.setInput(c.id, data); return; }
    if (type === 'chat') {
      const text = String(data.text ?? '').replace(/[\u0000-\u001f]/g, '').trim().slice(0, 160);
      const now = Date.now();
      if (!text || now - c.chatAt < 400) return;
      c.chatAt = now;
      this.pushChat({ from: m.name, text });
      return;
    }
    if (this.phase !== 'lobby' && this.phase !== 'countdown') return;
    const isHost = c.id === this.hostId;
    switch (type) {
      case 'role': {
        const role = data.role;
        if (!ROLES[role]) return;
        if (role !== 'seeker' && this.list().some(o => o.id !== m.id && o.role === role)) {
          this.hub.send(c.id, 'error', { message: `${ROLES[role].label} is already taken.` });
          return;
        }
        m.role = role; m.ready = false;
        break;
      }
      case 'ready': m.ready = !!data.ready; break;
      case 'addBot': if (!isHost) return; this.addBot(); break;
      case 'fillBots': if (!isHost) return; this.fillBots(); break;
      case 'kick': { if (!isHost) return; const t = this.members.get(data.id); if (t?.isBot) this.members.delete(t.id); break; }
      case 'start': {
        if (!isHost) return;
        const v = this.validate();
        if (!v.ok) { this.hub.send(c.id, 'error', { message: v.reason }); return; }
        this.startGame();
        return;
      }
      default: return;
    }
    this.broadcastLobby();
  }

  allReady() { const h = this.humans(); return h.length > 0 && h.every(m => m.ready); }

  tick(dt) {
    if (this.phase === 'lobby') {
      if (this.allReady() && this.validate().ok) { this.phase = 'countdown'; this.countdown = this.cfg.countdownSeconds; this.broadcastLobby(); }
    } else if (this.phase === 'countdown') {
      if (!this.allReady() || !this.validate().ok) { this.phase = 'lobby'; this.broadcastLobby(); return; }
      const before = Math.ceil(this.countdown);
      this.countdown -= dt;
      if (this.countdown <= 0) this.startGame();
      else if (Math.ceil(this.countdown) !== before) this.broadcastLobby();
    } else if (this.phase === 'playing') {
      this.game.tick(dt);
      for (const m of this.humans()) this.hub.send(m.id, 'snap', this.game.snapshotFor(m.id));
      this.game.events.length = 0;
      if (this.game.over) {
        this.phase = 'ended';
        this.endTimer = this.cfg.endScreenSeconds;
        for (const m of this.humans()) this.hub.send(m.id, 'end', { ...this.game.over, returnIn: this.cfg.endScreenSeconds });
        this.system(this.game.over.winner === 'seekers' ? 'Seekers win! ' + this.game.over.reason : 'Hunters win. ' + this.game.over.reason);
      }
    } else if (this.phase === 'ended') {
      this.endTimer -= dt;
      if (this.endTimer <= 0) this.backToLobby();
    }
  }

  startGame() {
    const roster = this.list().map(m => ({ id: m.id, name: m.name, role: m.role, isBot: m.isBot }));
    this.game = new Game(roster, this.cfg);
    this.phase = 'playing';
    const c = this.cfg;
    const base = {
      code: this.code, map: this.game.def,
      cfg: {
        matchSeconds: c.matchSeconds, prepSeconds: c.prepSeconds, lockdownSeconds: c.lockdownSeconds, evidenceNeeded: c.evidenceNeeded,
        hunterVision: c.hunterVision, seekerVision: c.seekerVision, abilities: c.abilities, staminaMax: c.staminaMax,
      },
    };
    for (const m of this.humans()) this.hub.send(m.id, 'start', { ...base, you: m.id, role: m.role });
    this.system('The doors close. The hunt begins.');
  }

  backToLobby() {
    for (const m of this.list()) if (m.left) this.members.delete(m.id);
    for (const m of this.humans()) m.ready = false;
    this.game = null;
    this.phase = 'lobby';
    this.broadcastLobby();
  }

  system(text) { this.pushChat({ system: true, text }); }
  pushChat(entry) {
    this.chat.push({ id: ++this.chatSeq, ...entry });
    if (this.chat.length > 60) this.chat.shift();
    this.broadcastLobby();
  }

  broadcastLobby() {
    const v = this.validate();
    const state = {
      code: this.code, isPublic: this.isPublic, phase: this.phase, hostId: this.hostId,
      countdown: this.phase === 'countdown' ? Math.ceil(this.countdown) : null,
      valid: v.ok, reason: v.reason, maxPlayers: this.cfg.maxPlayers,
      members: this.list().map(m => ({ id: m.id, name: m.name, role: m.role, ready: m.ready, isBot: m.isBot })),
      chat: this.chat.slice(-40),
    };
    for (const m of this.humans()) this.hub.send(m.id, 'lobby', state);
  }
}

/**
 * Hub: transport-agnostic server. Feed it connect/disconnect/message calls
 * and call tick(dt) at TICK_RATE; it replies through send(id, type, data).
 */
export class Hub {
  constructor(send, cfg = CONFIG) {
    this.send = send; this.cfg = cfg;
    this.clients = new Map(); this.rooms = new Map(); this.botSeq = 0;
  }

  connect(id) {
    this.clients.set(id, { id, name: 'Player', room: null, chatAt: 0 });
    this.send(id, 'welcome', { id });
  }

  disconnect(id) {
    const c = this.clients.get(id);
    if (!c) return;
    if (c.room) this.leaveRoom(c);
    this.clients.delete(id);
  }

  message(id, type, data) {
    const c = this.clients.get(id);
    if (!c || typeof type !== 'string') return;
    data = data && typeof data === 'object' ? data : {};
    switch (type) {
      case 'hello': c.name = cleanName(data.name); return;
      case 'quickPlay': return this.quickPlay(c);
      case 'create': return this.joinRoom(c, this.createRoom(false));
      case 'join': {
        const r = this.rooms.get(String(data.code ?? '').toUpperCase().trim());
        if (!r) return this.send(id, 'error', { message: 'No room with that code.' });
        return this.joinRoom(c, r);
      }
      case 'leave':
        if (c.room) this.leaveRoom(c);
        this.send(id, 'left', {});
        return;
      default:
        if (c.room) c.room.handle(c, type, data);
    }
  }

  quickPlay(c) {
    const room = [...this.rooms.values()].find(r => r.isPublic && r.phase === 'lobby' && r.members.size < this.cfg.maxPlayers && r !== c.room)
      || this.createRoom(true);
    this.joinRoom(c, room);
  }

  createRoom(isPublic) {
    let code;
    do { code = Array.from({ length: 4 }, () => CODE_CHARS[(Math.random() * CODE_CHARS.length) | 0]).join(''); } while (this.rooms.has(code));
    const r = new Room(this, code, isPublic);
    this.rooms.set(code, r);
    return r;
  }

  joinRoom(c, room) {
    if (room.phase !== 'lobby' && room.phase !== 'countdown') return this.send(c.id, 'error', { message: 'That match is already in progress.' });
    if (room.members.size >= this.cfg.maxPlayers) return this.send(c.id, 'error', { message: 'That room is full.' });
    if (c.room) this.leaveRoom(c);
    c.room = room;
    room.add(c);
  }

  leaveRoom(c) {
    const r = c.room;
    c.room = null;
    r.remove(c.id);
    if (!r.hasHumans()) this.rooms.delete(r.code);
  }

  tick(dt) { for (const r of this.rooms.values()) r.tick(dt); }
}
