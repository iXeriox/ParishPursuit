<!--
  Parish Pursuit · "Sanctuary of Shadows" — drop-in Vue 3 client
  ------------------------------------------------------------------
  <ParishPursuit server-url="http://localhost:3000" />   online (Socket.IO)
  <ParishPursuit offline />                               practice vs bots, no server

  Needs: vue@3.3+, socket.io-client@4 (online mode only, lazy-loaded), ./parish-core.js
-->
<template>
  <div ref="root" class="pp-root" tabindex="0" @contextmenu.prevent>
    <!-- ============================ MENU ============================ -->
    <div v-if="screen === 'menu' || screen === 'connecting'" class="pp-menu">
      <div class="pp-sky" aria-hidden="true">
        <svg class="pp-silhouette" viewBox="0 0 1200 400" preserveAspectRatio="xMidYMax slice">
          <path d="M0 400 L0 330 Q300 300 600 320 T1200 300 L1200 400Z" fill="#0b0d14" />
          <path d="M170 330 L170 200 L230 150 L290 200 L290 330Z M222 150 L222 90 M205 108 L239 108" fill="#0b0d14" stroke="#0b0d14" stroke-width="10" />
          <path d="M290 330 L290 230 L470 230 L470 330Z M300 230 L380 175 L460 230Z" fill="#0b0d14" />
          <rect x="203" y="245" width="38" height="85" rx="19" fill="#5fd4ff" opacity=".85" />
          <path d="M850 330 C850 200 900 150 960 140 C1030 150 1080 210 1090 330Z" fill="#07080c" />
          <circle cx="965" cy="105" r="48" fill="#07080c" />
          <rect x="948" y="150" width="34" height="10" fill="#e8e8e8" />
          <g fill="#07080c"><circle cx="640" cy="318" r="7"/><rect x="634" y="324" width="12" height="16" rx="5"/>
            <circle cx="690" cy="314" r="7"/><rect x="684" y="320" width="12" height="16" rx="5"/>
            <circle cx="735" cy="320" r="7"/><rect x="729" y="326" width="12" height="16" rx="5"/></g>
        </svg>
      </div>
      <div class="pp-menu-card">
        <h1 class="pp-title">SANCTUARY <span>OF SHADOWS</span></h1>
        <p class="pp-sub">An asymmetrical hunt in the parish of St. Dunstan</p>
        <label class="pp-field">
          <span>Your name</span>
          <input v-model="name" maxlength="16" placeholder="Player" @keydown.enter="quickPlay" />
        </label>
        <div v-if="screen === 'connecting'" class="pp-connecting">
          <div class="pp-loadbar"><i /></div>
          <span>Entering the parish…</span>
        </div>
        <template v-else>
          <button class="pp-btn pp-primary" @click="quickPlay">{{ offline ? 'Quick Match' : 'Quick Play' }}</button>
          <button class="pp-btn" @click="practice">Practice vs Bots</button>
          <div class="pp-row">
            <button class="pp-btn" @click="createRoom">Private Room</button>
            <input v-model="joinCode" class="pp-code" maxlength="4" placeholder="CODE" @keydown.enter="joinRoom" />
            <button class="pp-btn" :disabled="joinCode.length !== 4" @click="joinRoom">Join</button>
          </div>
        </template>
        <p class="pp-mode">{{ offline ? 'Offline mode · everything runs in your browser' : 'Online · ' + (serverUrl || 'same origin') }}</p>
      </div>
      <div v-if="error" class="pp-error">{{ error }}</div>
    </div>

    <!-- ============================ LOBBY ============================ -->
    <div v-else-if="screen === 'lobby' && lobby" class="pp-lobby">
      <header class="pp-lobby-head">
        <h2>MULTIPLAYER LOBBY</h2>
        <div class="pp-roomcode">Room <b>{{ lobby.code }}</b> <small>{{ lobby.isPublic ? 'public' : 'private' }}</small></div>
        <button class="pp-btn pp-ghost" @click="leave">Leave</button>
      </header>

      <div class="pp-lobby-grid">
        <section class="pp-panel pp-players">
          <h3>PLAYER LIST <small>{{ lobby.members.length }}/{{ lobby.maxPlayers }}</small></h3>
          <div v-for="m in lobby.members" :key="m.id" class="pp-prow"
               :class="{ ready: m.ready, hunter: isHunterRole(m.role), me: m.id === myId }">
            <canvas v-portrait="{ role: m.role, color: seekerColorIdx(m) }" class="pp-mini" width="44" height="44" />
            <div class="pp-pname">
              <b>{{ m.name }}</b>
              <small>{{ roleLabel(m.role) }}<template v-if="m.id === lobby.hostId"> · host</template></small>
            </div>
            <span class="pp-pstate" :title="m.ready ? 'Ready' : 'Not ready'">
              <template v-if="isHunterRole(m.role)">☠</template>
              <template v-else>{{ m.ready ? '✓' : '✕' }}</template>
            </span>
            <button v-if="isHost && m.isBot" class="pp-kick" title="Remove bot" @click="send('kick', { id: m.id })">×</button>
          </div>
          <div v-if="isHost" class="pp-hosttools">
            <button class="pp-btn pp-small" :disabled="lobby.members.length >= lobby.maxPlayers" @click="send('addBot')">+ Bot</button>
            <button class="pp-btn pp-small" @click="send('fillBots')">Fill with bots</button>
          </div>
        </section>

        <section class="pp-panel pp-roles">
          <h3>SELECT YOUR ROLE</h3>
          <div class="pp-rolegrid">
            <button v-for="(r, key) in ROLES" :key="key" class="pp-role"
                    :class="{ picked: me?.role === key, taken: takenBy(key), hunter: r.team === 'hunters' }"
                    :disabled="!!takenBy(key)" @click="send('role', { role: key })">
              <canvas v-portrait="{ role: key, color: 1 }" width="96" height="96" />
              <b>{{ r.label }}</b>
              <small class="pp-blurb">{{ r.blurb }}</small>
              <ul><li v-for="perk in r.perks" :key="perk">{{ perk }}</li></ul>
              <em v-if="takenBy(key)">Taken by {{ takenBy(key) }}</em>
            </button>
          </div>
        </section>

        <section class="pp-panel pp-chat">
          <h3>Chat Log</h3>
          <div ref="chatBox" class="pp-chatlog">
            <div v-for="l in lobby.chat" :key="l.id" :class="{ sys: l.system }">
              <template v-if="l.system">[System] {{ l.text }}</template>
              <template v-else><b>[{{ l.from }}]</b> {{ l.text }}</template>
            </div>
          </div>
          <form @submit.prevent="sendChat">
            <input v-model="chatText" maxlength="160" placeholder="Say something…" />
          </form>
        </section>
      </div>

      <footer class="pp-lobby-foot">
        <div class="pp-status">
          <template v-if="lobby.phase === 'countdown'">Doors close in <b>{{ lobby.countdown }}</b>…</template>
          <template v-else-if="!lobby.valid">{{ lobby.reason }}</template>
          <template v-else>Waiting for everyone to ready up</template>
        </div>
        <button v-if="isHost" class="pp-btn" :disabled="!lobby.valid" @click="send('start')">Start now</button>
        <button class="pp-btn pp-ready" :class="{ on: me?.ready }" @click="send('ready', { ready: !me?.ready })">
          {{ me?.ready ? 'Ready ✓' : 'Ready up' }}
        </button>
      </footer>
      <div v-if="error" class="pp-error">{{ error }}</div>
    </div>

    <!-- ============================ GAME ============================ -->
    <div v-show="screen === 'game'" class="pp-game">
      <canvas ref="canvas" class="pp-canvas"
              @mousemove="onMouse" @mousedown.left="castAbility" @mouseleave="mouse.active = false" />

      <div v-if="hud.you" class="pp-hud">
        <div class="pp-obj">
          <div class="pp-obj-h">OBJECTIVE:</div>
          <div v-for="(l, i) in objectiveLines" :key="i" :class="{ done: l.done, hot: l.hot }">{{ l.text }}</div>
        </div>

        <div class="pp-clock" :class="{ low: hud.timeLeft < 60 }">
          {{ fmt(hud.timeLeft) }}<small>until Morning Mass</small>
        </div>

        <div class="pp-tracker" title="Seekers ✓ free / ✕ jailed · hunters">
          <span v-for="r in seekerRoster" :key="r.id" class="pp-pip" :class="r.state" :title="r.name">
            <svg viewBox="0 0 20 24"><circle cx="10" cy="7" r="5.5" :fill="seekerColor(r.color)" /><rect x="3.5" y="12" width="13" height="10" rx="4" :fill="seekerColor(r.color)" /></svg>
            <i>{{ r.state === 'captured' ? '✕' : '✓' }}</i>
          </span>
          <span class="pp-sep" />
          <span v-for="r in hunterRoster" :key="r.id" class="pp-pip hunter" :title="r.name">
            <svg viewBox="0 0 20 24"><circle cx="10" cy="7" r="5.5" fill="#1b1e26" stroke="#c43a3a" /><rect x="3.5" y="12" width="13" height="10" rx="4" fill="#1b1e26" stroke="#c43a3a" /></svg>
            <i>☠</i>
          </span>
        </div>

        <div class="pp-toasts">
          <div v-for="t in hud.toasts" :key="t.id" class="pp-toast" :class="t.kind">{{ t.text }}</div>
        </div>

        <div v-if="hud.obj?.lockdown != null" class="pp-lockdown">
          LOCKDOWN: {{ fmt(hud.obj.lockdown) }}
          <small>{{ team === 'seekers' ? 'Police en route — survive!' : 'Reach the Bell Tower phone and cut the line!' }}</small>
        </div>

        <div v-if="hud.prep > 0" class="pp-banner">
          <template v-if="team === 'hunters'">Vespers… the hunt begins in {{ hud.prep }}</template>
          <template v-else>Scatter! The clergy wake in {{ hud.prep }}</template>
        </div>
        <div v-else-if="hud.you.state === 'captured'" class="pp-banner bad">
          You're in the holding cell. A friend can free you at the lever.
        </div>
        <div v-else-if="hud.you.stunned" class="pp-banner bad">Stunned!</div>

        <div v-if="prompt" class="pp-prompt"><kbd>E</kbd> Hold to {{ prompt }}</div>

        <div class="pp-minimap-wrap">
          <canvas ref="minimap" class="pp-minimap" />
          <span>{{ hud.room || '—' }}</span>
        </div>

        <div class="pp-actionbar">
          <template v-if="team === 'seekers'">
            <div class="pp-stamina" :class="{ tired: hud.you.exhausted }">
              <label>Stamina <kbd>Shift</kbd></label>
              <div><i :style="{ width: (hud.you.stamina * 100) + '%' }" /></div>
            </div>
          </template>
          <template v-else>
            <button class="pp-ability" :class="{ ready: hud.you.abilityCd <= 0 }"
                    :style="{ '--cd': (hud.you.abilityMax ? hud.you.abilityCd / hud.you.abilityMax : 0) }" @click="castAbility">
              <kbd>Q</kbd>
              <b>{{ abilityName }}</b>
              <small>{{ hud.you.abilityCd > 0 ? Math.ceil(hud.you.abilityCd) + 's' : 'Ready' }}</small>
            </button>
            <div class="pp-hint">Touch a seeker to jail them</div>
          </template>
        </div>

        <div class="pp-help">
          WASD move · Shift sprint · hold E interact{{ team === 'hunters' ? ' · Q / click ability (aim with mouse)' : '' }}
          <button class="pp-linkbtn" @click="leave">Leave match</button>
        </div>
      </div>

      <div v-if="hud.ended" class="pp-end">
        <div class="pp-end-card" :class="hud.ended.winner">
          <h2>{{ hud.ended.winner === 'seekers' ? 'SEEKERS WIN' : 'HUNTERS WIN' }}</h2>
          <p class="pp-end-you">{{ hud.ended.winner === team ? 'Victory' : 'Defeat' }} · {{ hud.ended.reason }}</p>
          <table>
            <thead><tr><th>Player</th><th>Role</th><th>Evidence</th><th>Rescues</th><th>Captures</th></tr></thead>
            <tbody>
              <tr v-for="p in hud.ended.players" :key="p.id" :class="{ me: p.id === myId }">
                <td>{{ p.name }}</td><td>{{ roleLabel(p.role) }}</td><td>{{ p.evidence }}</td><td>{{ p.rescues }}</td><td>{{ p.captures }}</td>
              </tr>
            </tbody>
          </table>
          <p class="pp-end-foot">Evidence {{ hud.ended.evidence }}/{{ hud.ended.need }} · {{ fmt(hud.ended.duration) }} · back to lobby in {{ hud.endIn }}s</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted, onBeforeUnmount, nextTick } from 'vue';
import { Hub, TICK_RATE, ROLES, makeMap, lightPolygon } from './parish-core.js';

const props = defineProps({
  /** Socket.IO server URL. Empty = same origin. */
  serverUrl: { type: String, default: '' },
  /** Run the whole game in the browser against bots (no server needed). */
  offline: { type: Boolean, default: false },
  /** Pre-fill the player's name. */
  playerName: { type: String, default: '' },
  /** CSS height of the component. */
  height: { type: String, default: '100%' },
});
const emit = defineEmits(['match-end']);

const SEEKER_COLORS = ['#3fae5a', '#3b82c4', '#d9822b', '#e3c341', '#9b5cc4', '#2bb3a3', '#d65f8a', '#c94a3b'];
const HAIR = ['#4a2f1c', '#1d1a17', '#7a4a22', '#c48a3a', '#2c2018', '#5a3a28', '#1d1a17', '#8a5a2a'];
const PROMPTS = {
  key: 'steal the Office Key', evidence: 'collect the evidence', rescue: 'pull the lever & free your friends',
  console: 'call the police', cancel: 'cut the phone line',
};

/* ---------------------------- reactive UI state ---------------------------- */
const root = ref(null), canvas = ref(null), minimap = ref(null), chatBox = ref(null);
const screen = ref('menu');
const name = ref(props.playerName || readName());
const joinCode = ref('');
const error = ref('');
const myId = ref(null);
const lobby = ref(null);
const chatText = ref('');
const mouse = reactive({ x: 0, y: 0, active: false });
const hud = reactive({ you: null, obj: null, roster: [], timeLeft: 0, prep: 0, room: '', toasts: [], ended: null, endIn: 0 });
const team = ref('seekers');
const myRole = ref('seeker');

const me = computed(() => lobby.value?.members.find(m => m.id === myId.value));
const isHost = computed(() => lobby.value?.hostId === myId.value);
const seekerRoster = computed(() => hud.roster.filter(r => r.team === 'seekers'));
const hunterRoster = computed(() => hud.roster.filter(r => r.team === 'hunters'));
const prompt = computed(() => (hud.you && !hud.you.interact && hud.you.prompt ? PROMPTS[hud.you.prompt] : ''));
const abilityName = computed(() => G.cfg?.abilities?.[myRole.value]?.name ?? '');
const objectiveLines = computed(() => {
  const o = hud.obj;
  if (!o) return [];
  if (team.value === 'seekers') {
    const lines = [];
    lines.push({ text: o.key ? 'Office Key stolen — crypt open' : 'Steal the Office Key — Vestry', done: o.key });
    lines.push({ text: `Find Evidence (${o.found}/${o.need})${o.key ? '' : ' · some lie in the locked crypt'}`, done: o.found >= o.need });
    if (o.found >= o.need) lines.push({ text: o.lockdown != null ? `Hold out — police in ${o.lockdown}s` : 'Contact Police — Bell Tower', hot: true });
    lines.push({ text: 'Evade the clergy' });
    return lines;
  }
  return [
    { text: `Jail every seeker (${o.jailed}/${o.seekers})` },
    { text: `Evidence exposed: ${o.found}/${o.need}`, hot: o.found >= o.need - 1 },
    { text: o.lockdown != null ? 'Cut the line — Bell Tower!' : o.found >= o.need ? 'The bell tower phone is live — guard it' : 'Guard the parish until Mass', hot: o.lockdown != null },
  ];
});

const isHunterRole = r => ROLES[r]?.team === 'hunters';
const roleLabel = r => ROLES[r]?.label ?? r;
const seekerColor = i => SEEKER_COLORS[(i ?? 0) % SEEKER_COLORS.length];
const takenBy = role => (role === 'seeker' ? null : lobby.value?.members.find(m => m.role === role && m.id !== myId.value)?.name ?? null);
const seekerColorIdx = m => lobby.value.members.filter(x => x.role === 'seeker').indexOf(m);
const fmt = s => { s = Math.max(0, Math.ceil(s ?? 0)); return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`; };

function readName() { try { return localStorage.getItem('pp-name') || ''; } catch { return ''; } }
function saveName() { try { localStorage.setItem('pp-name', name.value); } catch { /* storage unavailable */ } }

/* ------------------------------ transport ------------------------------ */
let transport = null;

function createLocalTransport(handler) {
  const LOCAL = 'local-player';
  const hub = new Hub((id, type, data) => { if (id === LOCAL) handler(type, data); });
  let last = performance.now();
  const iv = setInterval(() => {
    const now = performance.now();
    hub.tick(Math.min(0.1, (now - last) / 1000));
    last = now;
  }, 1000 / TICK_RATE);
  hub.connect(LOCAL);
  return { send: (t, d) => hub.message(LOCAL, t, d), close() { clearInterval(iv); hub.disconnect(LOCAL); } };
}

async function ensureTransport() {
  if (transport) return transport;
  if (props.offline) {
    transport = createLocalTransport(onMessage);
  } else {
    screen.value = 'connecting';
    const { io } = await import('socket.io-client');
    const socket = io(props.serverUrl || undefined, { transports: ['websocket'], reconnection: false, timeout: 6000 });
    socket.on('m', onMessage);
    await new Promise((resolve, reject) => {
      socket.once('connect', resolve);
      socket.once('connect_error', err => { socket.close(); reject(err); });
    });
    socket.on('disconnect', () => {
      transport = null;
      if (screen.value !== 'menu') { stopGame(); screen.value = 'menu'; showError('Lost connection to the server.'); }
    });
    transport = { send: (t, d) => socket.emit('m', t, d), close: () => socket.close() };
  }
  transport.send('hello', { name: name.value });
  return transport;
}

function send(type, data) { transport?.send(type, data); }

async function go(fn) {
  saveName();
  error.value = '';
  try { await ensureTransport(); fn(); }
  catch (err) { screen.value = 'menu'; showError(`Couldn't reach the server${props.serverUrl ? ' at ' + props.serverUrl : ''}.`); console.error(err); }
}
const quickPlay = () => go(() => send('quickPlay'));
const createRoom = () => go(() => send('create'));
const joinRoom = () => go(() => send('join', { code: joinCode.value }));
const practice = () => go(() => { send('create'); send('fillBots'); });
function leave() { send('leave'); stopGame(); screen.value = 'menu'; lobby.value = null; }
function sendChat() { if (chatText.value.trim()) send('chat', { text: chatText.value }); chatText.value = ''; }

let errTimer = 0;
function showError(msg) { error.value = msg; clearTimeout(errTimer); errTimer = setTimeout(() => { error.value = ''; }, 4000); }

function onMessage(type, data) {
  switch (type) {
    case 'welcome': myId.value = data.id; break;
    case 'lobby':
      lobby.value = data;
      if ((data.phase === 'lobby' || data.phase === 'countdown') && screen.value !== 'lobby') { stopGame(); screen.value = 'lobby'; }
      nextTick(() => { if (chatBox.value) chatBox.value.scrollTop = chatBox.value.scrollHeight; });
      break;
    case 'start': startMatch(data); break;
    case 'snap': onSnap(data); break;
    case 'end':
      hud.ended = data; G.endAt = performance.now() + data.returnIn * 1000;
      emit('match-end', data);
      break;
    case 'left': stopGame(); screen.value = 'menu'; lobby.value = null; break;
    case 'error': showError(data.message); break;
  }
}

/* ------------------------------ game state ------------------------------ */
// Non-reactive on purpose: rendered at 60fps from canvas, not through Vue.
const G = {
  def: null, map: null, cfg: null, mapCanvas: null, miniBase: null, snap: null,
  ents: new Map(), seenEvidence: new Set(), candles: [], doorsOpen: false,
  keys: new Set(), abilitySeq: 0, raf: 0, inputIv: 0, lastInput: '', lastInputAt: 0, lastAim: null,
  dpr: 1, tile: 32, cam: { x: 0, y: 0 }, shake: 0, flash: 0, frame: 0, endAt: 0, light: null, lastTs: 0,
};

function startMatch(data) {
  G.def = data.map; G.map = makeMap(data.map); G.cfg = data.cfg;
  myRole.value = data.role; team.value = ROLES[data.role].team;
  myId.value = data.you;
  G.ents.clear(); G.snap = null; G.seenEvidence.clear(); G.abilitySeq = 0; G.keys.clear(); G.lastAim = null;
  G.doorsOpen = false; G.shake = 0; G.flash = 0;
  G.mapCanvas = renderStaticMap(G.def);
  G.miniBase = renderMinimapBase(G.def);
  G.candles = buildCandles();
  Object.assign(hud, { you: null, obj: null, roster: [], toasts: [], ended: null, room: '' });
  screen.value = 'game';
  nextTick(() => {
    resize();
    root.value?.focus();
    cancelAnimationFrame(G.raf);
    G.lastTs = 0;
    G.raf = requestAnimationFrame(frame);
    clearInterval(G.inputIv);
    G.inputIv = setInterval(sendInput, 1000 / TICK_RATE);
  });
}

function stopGame() {
  cancelAnimationFrame(G.raf); G.raf = 0;
  clearInterval(G.inputIv); G.inputIv = 0;
  G.snap = null; G.keys.clear();
  hud.ended = null; hud.you = null;
}

function buildCandles() {
  return G.def.candles.map(([x, y]) => ({ x, y, seed: x * 7 + y * 13, pts: lightPolygon(G.map, x, y, 0, Math.PI, 3.2, 48) }));
}

let toastSeq = 0;
function onSnap(s) {
  G.snap = s;
  if (s.doors !== G.doorsOpen) { G.doorsOpen = s.doors; G.map.doorsOpen = s.doors; G.candles = buildCandles(); }
  const seen = new Set();
  for (const p of s.players) {
    seen.add(p.id);
    let e = G.ents.get(p.id);
    if (!e) { e = { ...p, rx: p.x, ry: p.y, rdir: p.dir, seed: Math.random() * 10 }; G.ents.set(p.id, e); }
    else {
      if (Math.hypot(p.x - e.rx, p.y - e.ry) > 3) { e.rx = p.x; e.ry = p.y; }
      Object.assign(e, p);
    }
  }
  for (const id of [...G.ents.keys()]) if (!seen.has(id)) G.ents.delete(id);

  for (const ev of s.events) {
    const t = eventText(ev);
    if (t) {
      hud.toasts.push({ id: ++toastSeq, text: t[0], kind: t[1], until: performance.now() + 4200 });
      if (hud.toasts.length > 4) hud.toasts.shift();
    }
    if (ev.type === 'capture' && ev.whoId === myId.value) { G.shake = 0.5; G.flash = 0.6; }
    if (ev.type === 'trap' || ev.type === 'tether') G.flash = Math.max(G.flash, 0.3);
  }
  hud.you = s.you; hud.obj = s.obj; hud.roster = s.roster; hud.timeLeft = s.timeLeft; hud.prep = s.prep;
}

function eventText(e) {
  const flip = team.value === 'hunters';
  const k = base => (base === 'info' ? 'info' : (base === 'good') !== flip ? 'good' : 'bad');
  switch (e.type) {
    case 'capture': return [`${e.by} caught ${e.who}`, k('bad')];
    case 'rescue': return [`${e.who} freed ${e.n} from the holding cell`, k('good')];
    case 'evidence': return [`${e.who} found evidence (${e.n}/${e.need})`, k('good')];
    case 'trap': return [`${e.who} touched tampered evidence!`, k('bad')];
    case 'key': return [`${e.who} stole the Office Key — the crypt is open`, k('good')];
    case 'consoleReady': return ['Enough evidence! The Bell Tower phone is live', k('good')];
    case 'lockdownStart': return [`${e.who} called the police — LOCKDOWN!`, k('good')];
    case 'lockdownCancel': return [`${e.who} cut the phone line!`, k('bad')];
    case 'tether': return [`The Nun's rosary snared ${e.who}`, k('bad')];
    case 'smoke': return ["The Bishop's smoke spreads…", 'info'];
    case 'corrupt': return [`Corruption Spread tainted ${e.n} evidence`, 'info'];
    case 'fizzle': return ['No untainted evidence nearby', 'info'];
    default: return null;
  }
}

/* -------------------------------- input -------------------------------- */
function onKeyDown(e) {
  if (screen.value !== 'game') return;
  if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
  const k = e.key.toLowerCase();
  if (['arrowup', 'arrowdown', 'arrowleft', 'arrowright', ' '].includes(k)) e.preventDefault();
  if ((k === 'q' || k === ' ') && !e.repeat) castAbility();
  G.keys.add(k);
}
function onKeyUp(e) { G.keys.delete(e.key.toLowerCase()); }
function onBlur() { G.keys.clear(); }
function castAbility() { if (team.value === 'hunters') G.abilitySeq++; }

function onMouse(e) {
  const r = canvas.value.getBoundingClientRect();
  mouse.x = (e.clientX - r.left) * G.dpr; mouse.y = (e.clientY - r.top) * G.dpr; mouse.active = true;
}

function sendInput() {
  if (!G.snap || !transport) return;
  const k = G.keys;
  const mx = (k.has('d') || k.has('arrowright') ? 1 : 0) - (k.has('a') || k.has('arrowleft') ? 1 : 0);
  const my = (k.has('s') || k.has('arrowdown') ? 1 : 0) - (k.has('w') || k.has('arrowup') ? 1 : 0);
  const self = G.ents.get(myId.value);
  let aimX = null, aimY = null;
  if (self) {
    if (mouse.active) {
      const cv = canvas.value;
      aimX = G.cam.x + (mouse.x - cv.width / 2) / G.tile;
      aimY = G.cam.y + (mouse.y - cv.height / 2) / G.tile;
    } else if (mx || my) {
      G.lastAim = Math.atan2(my, mx);
    }
    if (aimX == null && G.lastAim != null) { aimX = self.x + Math.cos(G.lastAim) * 3; aimY = self.y + Math.sin(G.lastAim) * 3; }
  }
  const inp = {
    mx, my, sprint: k.has('shift'), interact: k.has('e'),
    aimX: aimX == null ? null : Math.round(aimX * 100) / 100, aimY: aimY == null ? null : Math.round(aimY * 100) / 100,
    ability: G.abilitySeq,
  };
  const j = JSON.stringify(inp), now = performance.now();
  if (j === G.lastInput && now - G.lastInputAt < 250) return;
  G.lastInput = j; G.lastInputAt = now;
  transport.send('input', inp);
}

/* ------------------------------ rendering ------------------------------ */
let ro = null;
function resize() {
  const cv = canvas.value;
  if (!cv) return;
  G.dpr = Math.min(2, window.devicePixelRatio || 1);
  cv.width = Math.max(1, Math.round(cv.clientWidth * G.dpr));
  cv.height = Math.max(1, Math.round(cv.clientHeight * G.dpr));
  // light-map is rendered at reduced resolution and upscaled: lights are soft, fill cost drops ~9×
  G.light = G.light || document.createElement('canvas');
  G.light.width = Math.ceil(cv.width / LIGHT_SCALE); G.light.height = Math.ceil(cv.height / LIGHT_SCALE);
  if (minimap.value) {
    minimap.value.width = Math.round(minimap.value.clientWidth * G.dpr);
    minimap.value.height = Math.round(minimap.value.clientHeight * G.dpr);
  }
}

function frame(ts) {
  G.raf = requestAnimationFrame(frame);
  const dt = G.lastTs ? Math.min(0.05, (ts - G.lastTs) / 1000) : 0.016;
  G.lastTs = ts;
  if (!G.snap || !canvas.value) return;
  const k = 1 - Math.exp(-dt * 14);
  for (const e of G.ents.values()) {
    e.rx += (e.x - e.rx) * k; e.ry += (e.y - e.ry) * k;
    let d = e.dir - e.rdir; d = Math.atan2(Math.sin(d), Math.cos(d)); e.rdir += d * k;
  }
  G.shake = Math.max(0, G.shake - dt); G.flash = Math.max(0, G.flash - dt);
  draw(ts / 1000);
  if (++G.frame % 6 === 0) {
    drawMinimap();
    const nowMs = performance.now();
    if (hud.toasts.length && hud.toasts[0].until < nowMs) hud.toasts = hud.toasts.filter(t => t.until > nowMs);
    if (hud.ended) hud.endIn = Math.max(0, Math.ceil((G.endAt - nowMs) / 1000));
    const self = G.ents.get(myId.value);
    if (self) hud.room = G.map.roomAt(Math.floor(self.x), Math.floor(self.y));
  }
}

function draw(t) {
  const cv = canvas.value, ctx = cv.getContext('2d');
  const W = cv.width, H = cv.height, s = G.snap, def = G.def;
  const self = G.ents.get(myId.value);
  if (!self) return;
  const T = G.tile = Math.round(Math.max(22 * G.dpr, Math.min(56 * G.dpr, Math.min(W / 24, H / 15))));
  const shake = G.shake > 0 ? G.shake * 0.4 : 0;
  G.cam.x = self.rx + (Math.random() - 0.5) * shake; G.cam.y = self.ry + (Math.random() - 0.5) * shake;
  const sx = x => (x - G.cam.x) * T + W / 2, sy = y => (y - G.cam.y) * T + H / 2;
  const isHunter = team.value === 'hunters';

  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.fillStyle = '#05060a'; ctx.fillRect(0, 0, W, H);
  ctx.imageSmoothingEnabled = true;
  ctx.drawImage(G.mapCanvas, sx(0), sy(0), def.w * T, def.h * T);

  // doors
  for (let y = 0; y < def.h; y++) for (let x = 0; x < def.w; x++) {
    if (def.tiles[y][x] !== 'D') continue;
    const X = sx(x), Y = sy(y);
    if (X < -T || Y < -T || X > W || Y > H) continue;
    if (!s.doors) {
      ctx.fillStyle = '#4b2f1b'; ctx.fillRect(X, Y + T * 0.1, T, T * 0.8);
      ctx.fillStyle = '#2b1a0f'; for (let i = 1; i < 4; i++) ctx.fillRect(X + i * T / 4 - 1, Y + T * 0.1, 2, T * 0.8);
      ctx.fillStyle = '#6d6f75'; ctx.fillRect(X, Y + T * 0.25, T, T * 0.08); ctx.fillRect(X, Y + T * 0.65, T, T * 0.08);
      if (x % 2 === 0) { ctx.fillStyle = '#c9a24a'; ctx.beginPath(); ctx.arc(X + T, Y + T * 0.5, T * 0.12, 0, 7); ctx.fill(); }
    } else {
      ctx.fillStyle = '#3a2618'; ctx.fillRect(X, Y, T * 0.12, T); ctx.fillRect(X + T * 0.88, Y, T * 0.12, T);
    }
  }

  // objects: key, lever, console, evidence
  const glint = 0.5 + 0.5 * Math.sin(t * 4);
  if (!s.obj.key) drawKey(ctx, sx(def.key.x), sy(def.key.y), T, t);
  drawLever(ctx, sx(def.lever.x), sy(def.lever.y), T, s.obj.jailed > 0, t);
  const consoleLive = s.obj.consoleReady || s.obj.lockdown != null;
  for (const e of s.evidence) {
    if (Math.hypot(e.x - self.x, e.y - self.y) < 7) G.seenEvidence.add(e.id);
    drawEvidence(ctx, sx(e.x), sy(e.y), T, t + e.id, e.tampered, isHunter);
  }

  // smoke bodies (under characters, will be lit/darkened)
  for (const sm of s.smokes) drawSmoke(ctx, sx(sm.x), sy(sm.y), sm.r * T, t, sm.id, Math.min(1, sm.life));

  // tethers
  for (const th of s.tethers) drawTether(ctx, sx(th.ox), sy(th.oy), sx(th.x), sy(th.y), T, t);

  // characters, y-sorted
  const ents = [...G.ents.values()].sort((a, b) => a.ry - b.ry);
  for (const e of ents) drawCharacter(ctx, e, sx(e.rx), sy(e.ry), T, t);

  // interaction ring for me
  if (s.you.interact) {
    ctx.strokeStyle = 'rgba(0,0,0,.5)'; ctx.lineWidth = T * 0.12;
    ctx.beginPath(); ctx.arc(sx(self.rx), sy(self.ry) - T * 0.2, T * 0.62, 0, 7); ctx.stroke();
    ctx.strokeStyle = s.you.interact.kind === 'cancel' ? '#e04848' : '#f0c24b';
    ctx.lineWidth = T * 0.08;
    ctx.beginPath(); ctx.arc(sx(self.rx), sy(self.ry) - T * 0.2, T * 0.62, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * s.you.interact.p); ctx.stroke();
  }

  /* ---- lighting ---- */
  const L = G.light, lc = L.getContext('2d');
  lc.setTransform(1 / LIGHT_SCALE, 0, 0, 1 / LIGHT_SCALE, 0, 0);
  lc.globalCompositeOperation = 'source-over';
  lc.clearRect(0, 0, W, H);
  lc.fillStyle = 'rgba(3,4,9,0.955)';
  lc.fillRect(0, 0, W, H);
  lc.globalCompositeOperation = 'destination-out';
  const cut = (pts, cx, cy, R, a) => {
    const g = lc.createRadialGradient(sx(cx), sy(cy), 0, sx(cx), sy(cy), R * T);
    g.addColorStop(0, `rgba(0,0,0,${a})`); g.addColorStop(0.6, `rgba(0,0,0,${a * 0.8})`); g.addColorStop(1, 'rgba(0,0,0,0)');
    lc.fillStyle = g; lc.beginPath();
    pts.forEach(([x, y], i) => (i ? lc.lineTo(sx(x), sy(y)) : lc.moveTo(sx(x), sy(y))));
    lc.closePath(); lc.fill();
  };
  const radial = (cx, cy, R, a) => {
    const g = lc.createRadialGradient(sx(cx), sy(cy), 0, sx(cx), sy(cy), R * T);
    g.addColorStop(0, `rgba(0,0,0,${a})`); g.addColorStop(1, 'rgba(0,0,0,0)');
    lc.fillStyle = g; lc.fillRect(sx(cx) - R * T, sy(cy) - R * T, R * T * 2, R * T * 2);
  };
  const margin = 12;
  for (const c of G.candles) {
    if (Math.abs(c.x - G.cam.x) > W / T / 2 + margin || Math.abs(c.y - G.cam.y) > H / T / 2 + margin) continue;
    cut(c.pts, c.x, c.y, 3.2, 0.55 + 0.06 * Math.sin(t * 9 + c.seed));
  }
  radial(def.console.x, def.console.y + 0.6, consoleLive ? 3.2 : 1.6, consoleLive ? 0.85 : 0.45);
  for (const e of s.evidence) radial(e.x, e.y, 0.9, 0.35 + 0.25 * glint);
  if (!s.obj.key) radial(def.key.x, def.key.y, 0.9, 0.5);
  if (s.obj.jailed > 0) radial(def.lever.x, def.lever.y, 1.4, 0.5);

  for (const e of ents) {
    if (e.id === myId.value) continue;
    if (e.team === 'seekers' && e.state === 'free') {
      cut(lightPolygon(G.map, e.rx, e.ry, e.rdir, 0.45, 5, 28), e.rx, e.ry, 5, 0.4);
      radial(e.rx, e.ry, 1.2, 0.45);
    } else if (e.team === 'hunters') {
      cut(lightPolygon(G.map, e.rx, e.ry, 0, Math.PI, 3.2, 40), e.rx, e.ry, 3.2, 0.7);
    } else radial(e.rx, e.ry, 1.2, 0.5);
  }
  // my own vision
  const inSmoke = s.you.inSmoke && !isHunter;
  if (isHunter) {
    const R = G.cfg.hunterVision;
    cut(lightPolygon(G.map, self.rx, self.ry, 0, Math.PI, R, 200), self.rx, self.ry, R, 1);
  } else if (s.you.state === 'captured') {
    cut(lightPolygon(G.map, self.rx, self.ry, 0, Math.PI, 3.5, 90), self.rx, self.ry, 3.5, 1);
  } else {
    const amb = inSmoke ? 1.4 : 2.3, R = inSmoke ? 3 : G.cfg.seekerVision;
    cut(lightPolygon(G.map, self.rx, self.ry, 0, Math.PI, amb, 90), self.rx, self.ry, amb, 1);
    cut(lightPolygon(G.map, self.rx, self.ry, self.rdir, 0.62, R, 90), self.rx, self.ry, R, 1);
  }
  lc.globalCompositeOperation = 'source-over';
  ctx.drawImage(L, 0, 0, L.width * LIGHT_SCALE, L.height * LIGHT_SCALE);

  // warm glows on top
  ctx.globalCompositeOperation = 'lighter';
  const glow = (x, y, R, col) => {
    const g = ctx.createRadialGradient(x, y, 0, x, y, R);
    g.addColorStop(0, col); g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g; ctx.fillRect(x - R, y - R, R * 2, R * 2);
  };
  for (const c of G.candles) {
    const X = sx(c.x), Y = sy(c.y);
    if (X < -T * 3 || Y < -T * 3 || X > W + T * 3 || Y > H + T * 3) continue;
    glow(X, Y, T * (1.6 + 0.1 * Math.sin(t * 11 + c.seed)), 'rgba(255,150,60,0.16)');
    ctx.fillStyle = 'rgba(255,210,140,0.9)'; ctx.beginPath(); ctx.ellipse(X, Y - T * 0.08, T * 0.05, T * 0.1, 0, 0, 7); ctx.fill();
  }
  for (const e of ents) if (e.team === 'hunters') glow(sx(e.rx) + T * 0.26, sy(e.ry), T * 1.2, e.role === 'bishop' ? 'rgba(255,90,60,0.22)' : 'rgba(255,130,40,0.22)');
  if (consoleLive) glow(sx(def.console.x), sy(def.console.y), T * (2 + 0.3 * glint), s.obj.lockdown != null ? 'rgba(255,40,40,0.25)' : 'rgba(60,180,255,0.3)');
  ctx.globalCompositeOperation = 'source-over';

  // smoke rims above darkness
  for (const sm of s.smokes) {
    const a = Math.min(1, sm.life), R = sm.r * T, X = sx(sm.x), Y = sy(sm.y);
    const g = ctx.createRadialGradient(X, Y, R * 0.82, X, Y, R * 1.12);
    g.addColorStop(0, 'rgba(230,40,40,0)'); g.addColorStop(0.55, `rgba(230,40,40,${0.45 * a})`); g.addColorStop(1, 'rgba(230,40,40,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(X, Y, R * 1.12, 0, 7); ctx.fill();
  }

  // room labels
  ctx.font = `600 ${Math.round(T * 0.36)}px ${FONT}`; ctx.textAlign = 'center'; ctx.fillStyle = 'rgba(200,210,230,.5)';
  for (const r of def.rooms) if (r.label !== false) ctx.fillText(r.name, sx(r.x + r.w / 2), sy(r.y + 0.75));

  // names
  ctx.font = `600 ${Math.round(T * 0.28)}px ${FONT}`;
  for (const e of ents) {
    if (e.id === myId.value) continue;
    ctx.fillStyle = e.team === 'hunters' ? 'rgba(255,120,120,.85)' : 'rgba(230,240,255,.8)';
    ctx.fillText(e.name, sx(e.rx), sy(e.ry) - T * (e.role === 'bishop' ? 1.05 : 0.75));
  }

  // danger vignette for seekers
  if (!isHunter && s.you.state === 'free') {
    let nd = Infinity;
    for (const e of ents) if (e.team === 'hunters') nd = Math.min(nd, Math.hypot(e.x - self.x, e.y - self.y));
    if (nd < 7) {
      const beat = 0.5 + 0.5 * Math.pow(Math.max(0, Math.sin(t * (4 + (7 - nd)))), 6);
      const a = (1 - nd / 7) * 0.55 * beat;
      const g = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.3, W / 2, H / 2, Math.max(W, H) * 0.7);
      g.addColorStop(0, 'rgba(160,0,0,0)'); g.addColorStop(1, `rgba(160,0,0,${a})`);
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    }
  }
  if (G.flash > 0) { ctx.fillStyle = `rgba(200,20,20,${G.flash * 0.45})`; ctx.fillRect(0, 0, W, H); }
}

const LIGHT_SCALE = 3;
const FONT = "'Oswald','Bebas Neue','Arial Narrow',Impact,sans-serif";

function drawKey(ctx, x, y, T, t) {
  const b = Math.sin(t * 3) * T * 0.05;
  ctx.save(); ctx.translate(x, y + b); ctx.rotate(-0.5);
  ctx.strokeStyle = '#f2c54b'; ctx.fillStyle = '#f2c54b'; ctx.lineWidth = T * 0.07;
  ctx.beginPath(); ctx.arc(-T * 0.16, 0, T * 0.1, 0, 7); ctx.stroke();
  ctx.fillRect(-T * 0.06, -T * 0.03, T * 0.32, T * 0.06);
  ctx.fillRect(T * 0.16, 0, T * 0.05, T * 0.1); ctx.fillRect(T * 0.22, 0, T * 0.04, T * 0.07);
  ctx.restore();
}

function drawLever(ctx, x, y, T, live, t) {
  ctx.fillStyle = '#2b2f38'; ctx.fillRect(x - T * 0.18, y - T * 0.3, T * 0.36, T * 0.5);
  ctx.strokeStyle = '#8a8f99'; ctx.lineWidth = T * 0.06;
  ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + T * 0.18, y - T * 0.35); ctx.stroke();
  ctx.fillStyle = live ? `rgba(255,${60 + 40 * Math.sin(t * 6)},60,1)` : '#5a2020';
  ctx.beginPath(); ctx.arc(x + T * 0.18, y - T * 0.35, T * 0.07, 0, 7); ctx.fill();
}

function drawEvidence(ctx, x, y, T, t, tampered, isHunter) {
  // seekers get a subtle tell: tampered sparkle flickers red now and then
  const showBad = tampered && (isHunter || Math.sin(t * 2.3) > 0.55);
  const col = showBad ? (isHunter ? '#c04ae0' : '#e04848') : '#ffd25a';
  ctx.save(); ctx.translate(x, y); ctx.rotate(t * 0.8);
  ctx.fillStyle = col;
  const r = T * (0.2 + 0.04 * Math.sin(t * 5));
  ctx.beginPath();
  for (let i = 0; i < 8; i++) { const a = (i / 8) * Math.PI * 2, rr = i % 2 ? r * 0.3 : r; ctx.lineTo(Math.cos(a) * rr, Math.sin(a) * rr); }
  ctx.closePath(); ctx.fill();
  ctx.restore();
  ctx.fillStyle = 'rgba(240,230,200,.85)'; ctx.fillRect(x - T * 0.1, y + T * 0.12, T * 0.2, T * 0.14); // the paper itself
}

function drawSmoke(ctx, x, y, R, t, id, alpha) {
  for (let i = 0; i < 9; i++) {
    const a = id * 1.7 + i * 0.7, d = (i === 0 ? 0 : 0.55) * R;
    const px = x + Math.cos(a + t * 0.15) * d, py = y + Math.sin(a + t * 0.15) * d * 0.8;
    const g = ctx.createRadialGradient(px, py, 0, px, py, R * 0.6);
    g.addColorStop(0, `rgba(140,140,150,${0.55 * alpha})`); g.addColorStop(1, 'rgba(90,90,100,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(px, py, R * 0.6, 0, 7); ctx.fill();
  }
}

function drawTether(ctx, x0, y0, x1, y1, T, t) {
  const n = 14, dx = x1 - x0, dy = y1 - y0, L = Math.hypot(dx, dy) || 1, nx = -dy / L, ny = dx / L;
  ctx.beginPath();
  for (let i = 0; i <= n; i++) {
    const f = i / n, w = Math.sin(f * Math.PI * 3 + t * 20) * T * 0.08 * Math.sin(f * Math.PI);
    const px = x0 + dx * f + nx * w, py = y0 + dy * f + ny * w;
    i ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
  }
  ctx.strokeStyle = 'rgba(255,240,210,.25)'; ctx.lineWidth = T * 0.14; ctx.stroke();
  ctx.strokeStyle = 'rgba(255,245,225,.95)'; ctx.lineWidth = T * 0.04; ctx.stroke();
  ctx.fillStyle = '#fff6dc';
  for (let i = 1; i < n; i += 2) { const f = i / n; ctx.beginPath(); ctx.arc(x0 + dx * f, y0 + dy * f, T * 0.035, 0, 7); ctx.fill(); }
  ctx.strokeStyle = '#f0c24b'; ctx.beginPath(); ctx.arc(x1, y1, T * 0.12, 0, 7); ctx.stroke();
}

function rrect(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.roundRect ? ctx.roundRect(x, y, w, h, r) : ctx.rect(x, y, w, h); }

function drawCharacter(ctx, e, x, y, s, t) {
  ctx.save(); ctx.translate(x, y);
  if (e.state === 'captured') ctx.globalAlpha = 0.8;
  ctx.fillStyle = 'rgba(0,0,0,.45)'; ctx.beginPath(); ctx.ellipse(0, s * 0.3, s * 0.3, s * 0.1, 0, 0, 7); ctx.fill();
  if (e.invuln) { ctx.strokeStyle = `rgba(255,240,160,${0.5 + 0.3 * Math.sin(t * 10)})`; ctx.lineWidth = s * 0.04; ctx.beginPath(); ctx.ellipse(0, s * 0.3, s * 0.38, s * 0.13, 0, 0, 7); ctx.stroke(); }
  const bob = e.moving ? Math.abs(Math.sin(t * (e.sprinting ? 16 : 10) + (e.seed || 0))) * s * 0.05 : 0;
  ctx.translate(0, -bob);
  const dir = e.rdir ?? e.dir ?? Math.PI / 2, fx = Math.cos(dir), fy = Math.sin(dir);
  const eyes = (col, yy = -s * 0.27, glow = false) => {
    if (fy < -0.7) return;
    for (const side of [-1, 1]) {
      const ex = side * s * 0.07 + fx * s * 0.05, ey = yy + fy * s * 0.03;
      if (glow) { ctx.fillStyle = 'rgba(255,40,40,.25)'; ctx.beginPath(); ctx.arc(ex, ey, s * 0.06, 0, 7); ctx.fill(); }
      ctx.fillStyle = col; ctx.beginPath(); ctx.arc(ex, ey, s * 0.028, 0, 7); ctx.fill();
    }
  };
  const robe = (top, bottom, col, edge) => {
    ctx.fillStyle = col; ctx.beginPath();
    ctx.moveTo(-top, -s * 0.14); ctx.lineTo(top, -s * 0.14); ctx.lineTo(bottom, s * 0.29); ctx.lineTo(-bottom, s * 0.29); ctx.closePath(); ctx.fill();
    if (edge) { ctx.strokeStyle = edge; ctx.lineWidth = s * 0.025; ctx.stroke(); }
  };
  const head = (col, r = s * 0.19) => { ctx.fillStyle = col; ctx.beginPath(); ctx.arc(0, -s * 0.28, r, 0, 7); ctx.fill(); };
  const lantern = col => {
    const lx = (fx >= 0 ? 1 : -1) * s * 0.27, ly = s * 0.04 + Math.sin(t * 5) * s * 0.02;
    ctx.strokeStyle = '#6d5a3a'; ctx.lineWidth = s * 0.02; ctx.beginPath(); ctx.moveTo(lx * 0.7, -s * 0.02); ctx.lineTo(lx, ly - s * 0.06); ctx.stroke();
    ctx.fillStyle = '#b8923a'; ctx.fillRect(lx - s * 0.05, ly - s * 0.06, s * 0.1, s * 0.12);
    ctx.fillStyle = col; ctx.fillRect(lx - s * 0.03, ly - s * 0.035, s * 0.06, s * 0.07);
  };

  if (e.team === 'seekers') {
    const col = SEEKER_COLORS[(e.color ?? 0) % SEEKER_COLORS.length];
    ctx.fillStyle = '#272b35';
    const step = e.moving ? Math.sin(t * (e.sprinting ? 16 : 10) + (e.seed || 0)) * s * 0.04 : 0;
    rrect(ctx, -s * 0.14, s * 0.12 + step, s * 0.11, s * 0.17, s * 0.04); ctx.fill();
    rrect(ctx, s * 0.03, s * 0.12 - step, s * 0.11, s * 0.17, s * 0.04); ctx.fill();
    ctx.fillStyle = col; rrect(ctx, -s * 0.2, -s * 0.13, s * 0.4, s * 0.31, s * 0.1); ctx.fill();
    ctx.fillStyle = 'rgba(0,0,0,.18)'; rrect(ctx, -s * 0.2, s * 0.06, s * 0.4, s * 0.12, s * 0.06); ctx.fill();
    head('#f0c8a0');
    ctx.fillStyle = HAIR[(e.color ?? 0) % HAIR.length];
    ctx.beginPath(); ctx.arc(0, -s * 0.3, s * 0.2, Math.PI * 1.02, Math.PI * 1.98); ctx.fill();
    eyes('#2a2018');
    // flashlight
    ctx.fillStyle = '#9aa3b2'; ctx.fillRect(fx * s * 0.22 - s * 0.04, fy * s * 0.12 - s * 0.03, s * 0.08, s * 0.06);
  } else if (e.role === 'dave') {
    robe(s * 0.17, s * 0.25, '#15171d', '#2c3140');
    ctx.fillStyle = '#f2f2f2'; ctx.fillRect(-s * 0.04, -s * 0.15, s * 0.08, s * 0.05);
    head('#ddb08a');
    ctx.fillStyle = '#2b1d14'; ctx.beginPath(); ctx.arc(0, -s * 0.3, s * 0.195, Math.PI * 1.05, Math.PI * 1.95); ctx.fill();
    ctx.beginPath(); ctx.arc(0, -s * 0.25, s * 0.16, Math.PI * 0.15, Math.PI * 0.85); ctx.fill();
    eyes('#ff3b3b', -s * 0.29, true);
    lantern('#ffb347');
  } else if (e.role === 'nun') {
    robe(s * 0.18, s * 0.27, '#121318', '#272a33');
    ctx.fillStyle = '#121318'; ctx.beginPath(); ctx.arc(0, -s * 0.27, s * 0.25, 0, 7); ctx.fill();
    ctx.beginPath(); ctx.moveTo(-s * 0.25, -s * 0.27); ctx.lineTo(-s * 0.27, s * 0.02); ctx.lineTo(s * 0.27, s * 0.02); ctx.lineTo(s * 0.25, -s * 0.27); ctx.fill();
    ctx.fillStyle = '#ecebe6'; ctx.beginPath(); ctx.arc(0, -s * 0.26, s * 0.17, 0, 7); ctx.fill();
    ctx.fillStyle = '#f1d6bf'; ctx.beginPath(); ctx.arc(0, -s * 0.24, s * 0.13, 0, 7); ctx.fill();
    ctx.fillStyle = '#ecebe6'; rrect(ctx, -s * 0.15, -s * 0.11, s * 0.3, s * 0.09, s * 0.04); ctx.fill();
    eyes('#c62828', -s * 0.25, true);
    ctx.strokeStyle = '#e8d9b0'; ctx.lineWidth = s * 0.02; ctx.beginPath(); ctx.arc(0, -s * 0.02, s * 0.1, 0.2, Math.PI - 0.2); ctx.stroke();
  } else {
    robe(s * 0.17, s * 0.26, '#e7dec6', '#c9a24a');
    ctx.fillStyle = '#a3242c'; ctx.fillRect(-s * 0.09, -s * 0.14, s * 0.05, s * 0.43); ctx.fillRect(s * 0.04, -s * 0.14, s * 0.05, s * 0.43);
    head('#e0b896');
    ctx.fillStyle = '#9b9b9b'; ctx.beginPath(); ctx.arc(0, -s * 0.24, s * 0.15, Math.PI * 0.1, Math.PI * 0.9); ctx.fill();
    ctx.fillStyle = '#efe6cf'; ctx.strokeStyle = '#c9a24a'; ctx.lineWidth = s * 0.025;
    ctx.beginPath(); ctx.moveTo(-s * 0.15, -s * 0.38); ctx.lineTo(-s * 0.12, -s * 0.6); ctx.lineTo(0, -s * 0.72); ctx.lineTo(s * 0.12, -s * 0.6); ctx.lineTo(s * 0.15, -s * 0.38); ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#a3242c'; ctx.fillRect(-s * 0.015, -s * 0.62, s * 0.03, s * 0.16); ctx.fillRect(-s * 0.06, -s * 0.57, s * 0.12, s * 0.03);
    eyes('#ff4d3b', -s * 0.29, true);
    ctx.strokeStyle = '#c9a24a'; ctx.lineWidth = s * 0.035;
    ctx.beginPath(); ctx.moveTo(-s * 0.3, s * 0.28); ctx.lineTo(-s * 0.3, -s * 0.5); ctx.arc(-s * 0.24, -s * 0.5, s * 0.06, Math.PI, Math.PI * 2.4); ctx.stroke();
    lantern('#ff6a3d');
  }

  if (e.stunned) {
    ctx.fillStyle = '#ffe17a';
    for (let i = 0; i < 3; i++) { const a = t * 5 + i * 2.1; ctx.beginPath(); ctx.arc(Math.cos(a) * s * 0.2, -s * 0.55 + Math.sin(a) * s * 0.06, s * 0.04, 0, 7); ctx.fill(); }
  }
  if (e.rooted) {
    ctx.fillStyle = '#fff6dc';
    for (let i = 0; i < 10; i++) { const a = i / 10 * Math.PI * 2 + t * 2; ctx.beginPath(); ctx.arc(Math.cos(a) * s * 0.3, s * 0.05 + Math.sin(a) * s * 0.12, s * 0.03, 0, 7); ctx.fill(); }
  }
  if (e.revealed && e.team === 'seekers') {
    ctx.strokeStyle = `rgba(255,60,60,${0.5 + 0.4 * Math.sin(t * 12)})`; ctx.lineWidth = s * 0.04;
    ctx.beginPath(); ctx.arc(0, -s * 0.05, s * 0.42, 0, 7); ctx.stroke();
  }
  ctx.restore();
}

/* Pre-rendered map art (40px per tile) */
function renderStaticMap(def) {
  const P = 40, cv = document.createElement('canvas');
  cv.width = def.w * P; cv.height = def.h * P;
  const g = cv.getContext('2d'), map = makeMap(def);
  const hash = (x, y) => (((x * 73856093) ^ (y * 19349663)) >>> 0) % 1000 / 1000;
  const wall = (x, y) => { const ch = map.tile(x, y); return ch === '#'; };

  for (let y = 0; y < def.h; y++) for (let x = 0; x < def.w; x++) {
    const ch = def.tiles[y][x], X = x * P, Y = y * P;
    if (ch === '#') continue;
    const room = map.roomAt(x, y), crypt = room === 'Catacombs' || (x >= 6 && x <= 7 && y >= 24) || (x >= 45 && x <= 46 && y >= 24);
    const v = hash(x, y);
    g.fillStyle = crypt ? `hsl(28, 10%, ${10 + v * 4}%)` : room === 'Bell Tower' ? `hsl(25, 18%, ${12 + v * 3}%)` : `hsl(222, 18%, ${13 + v * 4}%)`;
    g.fillRect(X, Y, P, P);
    g.strokeStyle = 'rgba(0,0,0,.35)'; g.lineWidth = 1;
    if (room === 'Bell Tower') { for (let i = 1; i < 4; i++) { g.beginPath(); g.moveTo(X, Y + i * P / 4); g.lineTo(X + P, Y + i * P / 4); g.stroke(); } }
    else g.strokeRect(X + 0.5, Y + 0.5, P - 1, P - 1);
    if (crypt && v > 0.8) { g.fillStyle = 'rgba(200,190,170,.12)'; g.beginPath(); g.arc(X + v * P, Y + (1 - v) * P, 3, 0, 7); g.fill(); }

    if (ch === ',') {
      g.fillStyle = '#521820'; g.fillRect(X, Y, P, P);
      g.fillStyle = '#b8923a';
      if (x === 24) g.fillRect(X + 3, Y, 2, P);
      if (x === 27) g.fillRect(X + P - 5, Y, 2, P);
    } else if (ch === '=') {
      g.fillStyle = '#3d2618'; g.fillRect(X + 1, Y + 6, P - 2, P - 12);
      g.fillStyle = '#5e3d27'; g.fillRect(X + 1, Y + 6, P - 2, 6);
      g.fillStyle = '#2a190f'; g.fillRect(X + 1, Y + P - 9, P - 2, 3);
    } else if (ch === 'X') {
      if (room === 'Catacombs') {
        g.fillStyle = '#3b3b43'; g.fillRect(X + 2, Y + 4, P - 4, P - 8);
        g.fillStyle = '#4c4c55'; g.fillRect(X + 2, Y + 4, P - 4, 5);
        g.fillStyle = '#26262c'; g.fillRect(X + P / 2 - 2, Y + 10, 4, 16); g.fillRect(X + P / 2 - 7, Y + 15, 14, 4);
      } else if (room === 'Confessional') {
        g.fillStyle = '#3a2416'; g.fillRect(X + 1, Y + 1, P - 2, P - 2);
        g.strokeStyle = '#5c3a22'; for (let i = 6; i < P; i += 7) { g.beginPath(); g.moveTo(X + i, Y + 3); g.lineTo(X + i, Y + P - 3); g.stroke(); }
      } else {
        g.fillStyle = '#5a3c25'; g.fillRect(X + 1, Y + 3, P - 2, P - 6);
        g.fillStyle = '#6e4b30'; g.fillRect(X + 1, Y + 3, P - 2, 5);
        if (room === 'Vestry' && x === 7 && y === 5) { g.fillStyle = '#e9e1cf'; g.fillRect(X + 8, Y + 12, 14, 18); g.fillStyle = '#c9a24a'; g.fillRect(X + 26, Y + 14, 6, 10); }
      }
    } else if (ch === 'A') {
      g.fillStyle = '#d8d0bb'; g.fillRect(X, Y + 4, P, P - 8);
      g.fillStyle = '#b8923a'; g.fillRect(X, Y + P - 10, P, 3);
      if ((x === 25 && y === 3) || (x === 4 && y === 14)) { g.fillStyle = '#b8923a'; g.fillRect(X + P - 3, Y + 7, 6, 18); g.fillRect(X + P - 9, Y + 12, 18, 5); }
    } else if (ch === 'T') {
      g.fillStyle = '#2a2f3a'; g.fillRect(X - 6, Y + 10, P + 12, P - 12);
      g.fillStyle = '#0d1117'; g.fillRect(X + 4, Y + 2, P - 8, P - 16);
      g.fillStyle = '#0f3b52'; g.fillRect(X + 7, Y + 5, P - 14, P - 22);
    } else if (ch === '|') {
      g.fillStyle = '#7d828c';
      for (let i = 0; i < 4; i++) g.fillRect(X + 4 + i * 10, Y, 3, P);
      g.fillRect(X, Y + 4, P, 3); g.fillRect(X, Y + P - 7, P, 3);
    }
  }

  // walls with a 2.5D face where floor lies beneath
  for (let y = 0; y < def.h; y++) for (let x = 0; x < def.w; x++) {
    if (!wall(x, y)) continue;
    const X = x * P, Y = y * P;
    g.fillStyle = '#0a0d14'; g.fillRect(X, Y, P, P);
    const below = y + 1 < def.h && !wall(x, y + 1);
    if (below) {
      g.fillStyle = '#262d3d'; g.fillRect(X, Y + P * 0.42, P, P * 0.58);
      g.strokeStyle = '#1b2130'; g.lineWidth = 2;
      for (let r = 0; r < 3; r++) {
        const yy = Y + P * 0.42 + r * P * 0.2;
        g.beginPath(); g.moveTo(X, yy); g.lineTo(X + P, yy); g.stroke();
        const off = (r % 2) * P / 2;
        g.beginPath(); g.moveTo(X + off + P / 4, yy); g.lineTo(X + off + P / 4, yy + P * 0.2); g.stroke();
      }
      g.fillStyle = '#3b4458'; g.fillRect(X, Y + P * 0.42 - 2, P, 3);
    }
    g.strokeStyle = '#232a3a'; g.lineWidth = 2;
    if (y > 0 && !wall(x, y - 1)) { g.beginPath(); g.moveTo(X, Y + 1); g.lineTo(X + P, Y + 1); g.stroke(); }
    if (x > 0 && !wall(x - 1, y)) { g.beginPath(); g.moveTo(X + 1, Y); g.lineTo(X + 1, Y + P); g.stroke(); }
    if (x + 1 < def.w && !wall(x + 1, y)) { g.beginPath(); g.moveTo(X + P - 1, Y); g.lineTo(X + P - 1, Y + P); g.stroke(); }
  }

  // stained-glass windows along the nave's north wall + cross above the altar
  const panes = ['#c0392b', '#2e86c1', '#d4ac0d', '#7d3c98', '#17a589'];
  for (const wx of [17, 21, 30, 34]) {
    const X = wx * P + 8, Y = 1 * P + P * 0.48;
    g.fillStyle = '#11141c'; g.beginPath(); g.moveTo(X, Y + P * 0.5); g.lineTo(X, Y + 6); g.arc(X + 12, Y + 6, 12, Math.PI, 0); g.lineTo(X + 24, Y + P * 0.5); g.fill();
    for (let i = 0; i < 6; i++) { g.fillStyle = panes[(wx + i) % panes.length]; g.globalAlpha = 0.75; g.fillRect(X + 3 + (i % 2) * 9, Y + 4 + Math.floor(i / 2) * 6, 8, 5); }
    g.globalAlpha = 1;
  }
  g.fillStyle = '#c9a24a'; g.fillRect(25.9 * P, 1 * P + P * 0.45, 6, P * 0.55); g.fillRect(25.9 * P - 8, 1 * P + P * 0.58, 22, 5);
  return cv;
}

function renderMinimapBase(def) {
  const P = 4, cv = document.createElement('canvas');
  cv.width = def.w * P; cv.height = def.h * P;
  const g = cv.getContext('2d');
  for (let y = 0; y < def.h; y++) for (let x = 0; x < def.w; x++) {
    const ch = def.tiles[y][x];
    if (ch === '#') continue;
    g.fillStyle = ch === '.' || ch === ',' || ch === 'D' ? '#59627a' : '#444c60';
    g.fillRect(x * P, y * P, P, P);
  }
  return cv;
}

function drawMinimap() {
  const cv = minimap.value, s = G.snap;
  if (!cv || !s || !G.miniBase) return;
  const ctx = cv.getContext('2d'), def = G.def;
  const k = Math.min(cv.width / def.w, cv.height / def.h);
  const ox = (cv.width - def.w * k) / 2, oy = (cv.height - def.h * k) / 2;
  const mx = x => ox + x * k, my = y => oy + y * k;
  ctx.clearRect(0, 0, cv.width, cv.height);
  ctx.globalAlpha = 0.9; ctx.drawImage(G.miniBase, ox, oy, def.w * k, def.h * k); ctx.globalAlpha = 1;
  const dot = (x, y, r, col) => { ctx.fillStyle = col; ctx.beginPath(); ctx.arc(mx(x), my(y), r * k, 0, 7); ctx.fill(); };
  if (!s.obj.key) dot(def.key.x, def.key.y, 0.8, '#f2c54b');
  for (const e of s.evidence) if (G.seenEvidence.has(e.id) || team.value === 'hunters') dot(e.x, e.y, 0.6, '#ffd25a');
  dot(def.console.x, def.console.y, 0.9, s.obj.lockdown != null ? '#ff4040' : s.obj.consoleReady ? '#47c2ff' : '#2a4a5a');
  if (s.obj.jailed) dot(def.lever.x, def.lever.y, 0.8, '#ff6060');
  for (const e of G.ents.values()) {
    if (e.id === myId.value) continue;
    dot(e.rx, e.ry, 0.8, e.team === 'hunters' ? '#ff4545' : seekerColor(e.color));
  }
  const self = G.ents.get(myId.value);
  if (self) {
    ctx.save(); ctx.translate(mx(self.rx), my(self.ry)); ctx.rotate(self.rdir + Math.PI / 2);
    ctx.fillStyle = '#4cff6a'; ctx.beginPath(); ctx.moveTo(0, -1.6 * k); ctx.lineTo(1.1 * k, 1.1 * k); ctx.lineTo(-1.1 * k, 1.1 * k); ctx.closePath(); ctx.fill();
    ctx.restore();
  }
}

/* Lobby portraits: draws a character into a <canvas> */
const vPortrait = {
  mounted: (el, b) => paintPortrait(el, b.value),
  updated: (el, b) => { if (b.value?.role !== b.oldValue?.role || b.value?.color !== b.oldValue?.color) paintPortrait(el, b.value); },
};
function paintPortrait(el, { role, color }) {
  const ctx = el.getContext('2d'), w = el.width, h = el.height;
  ctx.clearRect(0, 0, w, h);
  const e = { role, team: ROLES[role]?.team, color: Math.max(0, color ?? 0), dir: Math.PI / 2, rdir: Math.PI / 2, state: 'free' };
  const s = h * (role === 'bishop' ? 0.78 : 0.95);
  drawCharacter(ctx, e, w / 2, h * (role === 'bishop' ? 0.66 : 0.6), s, 0);
}

/* ------------------------------ lifecycle ------------------------------ */
onMounted(() => {
  window.addEventListener('keydown', onKeyDown);
  window.addEventListener('keyup', onKeyUp);
  window.addEventListener('blur', onBlur);
  ro = new ResizeObserver(() => { if (screen.value === 'game') resize(); });
  ro.observe(root.value);
});
onBeforeUnmount(() => {
  window.removeEventListener('keydown', onKeyDown);
  window.removeEventListener('keyup', onKeyUp);
  window.removeEventListener('blur', onBlur);
  ro?.disconnect();
  stopGame();
  transport?.close();
  transport = null;
});
</script>

<style scoped>
.pp-root {
  --pp-bg: #0b0e15; --pp-panel: #141925; --pp-panel2: #1b2130; --pp-line: #2a3246;
  --pp-text: #dfe5f0; --pp-dim: #8b95ab; --pp-gold: #e6b94a; --pp-red: #d13b3b; --pp-green: #3fae5a; --pp-blue: #47c2ff;
  --pp-font: 'Oswald', 'Bebas Neue', 'Arial Narrow', Impact, sans-serif;
  position: relative; width: 100%; height: v-bind(height); min-height: 540px; overflow: hidden;
  background: var(--pp-bg); color: var(--pp-text); font: 14px/1.4 system-ui, -apple-system, 'Segoe UI', sans-serif;
  outline: none; user-select: none;
}
.pp-root * { box-sizing: border-box; }
kbd { display: inline-block; min-width: 1.6em; padding: 0 .35em; border: 1px solid #4a536b; border-bottom-width: 2px; border-radius: 4px; background: #1c2232; font: 600 11px/1.5 system-ui, sans-serif; text-align: center; color: #fff; }

/* buttons & inputs */
.pp-btn { font-family: var(--pp-font); letter-spacing: .04em; text-transform: uppercase; font-size: 15px; padding: 10px 18px; border-radius: 6px; border: 1px solid var(--pp-line); background: var(--pp-panel2); color: var(--pp-text); cursor: pointer; transition: background .15s, border-color .15s, transform .05s; }
.pp-btn:hover:not(:disabled) { border-color: #4a5672; background: #222a3c; }
.pp-btn:active:not(:disabled) { transform: translateY(1px); }
.pp-btn:disabled { opacity: .45; cursor: not-allowed; }
.pp-primary { background: linear-gradient(#b8323a, #8e2129); border-color: #d4545b; color: #fff; }
.pp-primary:hover:not(:disabled) { background: linear-gradient(#c93a43, #9c2630); border-color: #e86a70; }
.pp-ghost { background: transparent; }
.pp-small { font-size: 13px; padding: 6px 10px; }
input { font: inherit; color: var(--pp-text); background: #0d111a; border: 1px solid var(--pp-line); border-radius: 6px; padding: 9px 12px; outline: none; }
input:focus { border-color: var(--pp-gold); }

/* menu */
.pp-menu { position: absolute; inset: 0; display: grid; place-items: center; }
.pp-sky { position: absolute; inset: 0; background: radial-gradient(120% 80% at 70% 20%, #8a1c22 0%, #4a0f16 35%, #170a10 70%, #07080c 100%); }
.pp-silhouette { position: absolute; left: 0; right: 0; bottom: 0; width: 100%; height: 70%; }
.pp-menu-card { position: relative; width: min(440px, 92%); padding: 28px 28px 20px; background: rgba(10, 12, 18, .82); border: 1px solid #3a2228; border-radius: 12px; box-shadow: 0 20px 60px rgba(0,0,0,.6); display: flex; flex-direction: column; gap: 10px; backdrop-filter: blur(4px); }
.pp-title { margin: 0; font: 700 44px/1 var(--pp-font); letter-spacing: .02em; color: #e9ecf2; text-shadow: 0 3px 0 #000; }
.pp-title span { display: block; color: var(--pp-red); }
.pp-sub { margin: 0 0 8px; color: var(--pp-dim); }
.pp-field { display: flex; flex-direction: column; gap: 4px; font-size: 12px; color: var(--pp-dim); text-transform: uppercase; letter-spacing: .06em; }
.pp-row { display: flex; gap: 8px; }
.pp-row .pp-btn:first-child { flex: 1; }
.pp-code { width: 84px; text-transform: uppercase; text-align: center; letter-spacing: .2em; font-weight: 700; }
.pp-mode { margin: 6px 0 0; font-size: 12px; color: #6b7590; text-align: center; }
.pp-connecting { display: flex; flex-direction: column; align-items: center; gap: 8px; padding: 14px 0; color: var(--pp-dim); font-family: var(--pp-font); letter-spacing: .1em; text-transform: uppercase; }
.pp-loadbar { width: 100%; height: 10px; border: 1px solid #555e73; border-radius: 6px; overflow: hidden; }
.pp-loadbar i { display: block; height: 100%; width: 40%; background: #e9ecf2; animation: pp-load 1.1s ease-in-out infinite; }
@keyframes pp-load { 0% { transform: translateX(-100%); } 100% { transform: translateX(260%); } }
.pp-error { position: absolute; left: 50%; bottom: 22px; transform: translateX(-50%); padding: 10px 16px; background: #3a1418; border: 1px solid var(--pp-red); border-radius: 8px; color: #ffd7d7; z-index: 20; }

/* lobby */
.pp-lobby { position: absolute; inset: 0; display: flex; flex-direction: column; padding: 16px; gap: 12px; background: radial-gradient(100% 70% at 50% 0%, #1a2030, var(--pp-bg)); }
.pp-lobby-head { display: flex; align-items: center; gap: 16px; }
.pp-lobby-head h2 { margin: 0; flex: 1; font: 700 28px/1 var(--pp-font); letter-spacing: .03em; }
.pp-roomcode { font-family: var(--pp-font); font-size: 18px; color: var(--pp-dim); }
.pp-roomcode b { color: var(--pp-gold); letter-spacing: .15em; }
.pp-roomcode small { font-size: 12px; margin-left: 4px; text-transform: uppercase; }
.pp-lobby-grid { flex: 1; min-height: 0; display: grid; grid-template-columns: minmax(220px, 1fr) minmax(320px, 2fr) minmax(220px, 1fr); gap: 12px; }
.pp-panel { background: var(--pp-panel); border: 1px solid var(--pp-line); border-radius: 10px; padding: 12px; display: flex; flex-direction: column; min-height: 0; overflow: hidden; }
.pp-panel h3 { margin: 0 0 10px; font: 600 17px/1 var(--pp-font); letter-spacing: .05em; display: flex; justify-content: space-between; }
.pp-panel h3 small { color: var(--pp-dim); font-size: 13px; }
.pp-players { overflow-y: auto; }
.pp-prow { display: flex; align-items: center; gap: 8px; padding: 4px 8px 4px 4px; margin-bottom: 6px; border-radius: 8px; background: #3a1a1e; border: 1px solid #5a2a30; }
.pp-prow.ready { background: #1d3a24; border-color: #2f6a3d; }
.pp-prow.hunter { background: #22202a; border-color: #4a3a55; }
.pp-prow.me { box-shadow: 0 0 0 1px var(--pp-gold) inset; }
.pp-mini { width: 40px; height: 40px; flex: none; border-radius: 6px; background: #0d111a; }
.pp-pname { flex: 1; display: flex; flex-direction: column; min-width: 0; }
.pp-pname b { font-family: var(--pp-font); font-weight: 500; font-size: 16px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.pp-pname small { color: var(--pp-dim); font-size: 11px; }
.pp-pstate { font-size: 18px; font-weight: 700; color: #ff7a7a; }
.pp-prow.ready .pp-pstate { color: #6fe08a; }
.pp-prow.hunter .pp-pstate { color: #c07cff; }
.pp-kick { border: 0; background: none; color: var(--pp-dim); font-size: 18px; cursor: pointer; }
.pp-hosttools { display: flex; gap: 6px; margin-top: auto; padding-top: 8px; }
.pp-rolegrid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; overflow-y: auto; }
.pp-role { position: relative; display: flex; flex-direction: column; align-items: center; gap: 4px; padding: 10px; border-radius: 10px; border: 1px solid var(--pp-line); background: linear-gradient(#1a2030, #121722); color: var(--pp-text); cursor: pointer; text-align: center; font: inherit; }
.pp-role canvas { width: 80px; height: 80px; }
.pp-role b { font: 600 18px/1.1 var(--pp-font); letter-spacing: .04em; text-transform: uppercase; }
.pp-role.hunter b { color: #ff9a9a; }
.pp-blurb { color: var(--pp-dim); font-size: 12px; }
.pp-role ul { margin: 4px 0 0; padding: 0; list-style: none; font-size: 11.5px; color: #c3cad9; }
.pp-role li::before { content: '· '; color: var(--pp-gold); }
.pp-role em { position: absolute; top: 8px; right: 8px; font-size: 10px; color: #ff9a9a; font-style: normal; }
.pp-role.picked { border-color: var(--pp-gold); box-shadow: 0 0 0 1px var(--pp-gold), 0 0 24px rgba(230, 185, 74, .2); }
.pp-role.taken { opacity: .45; cursor: not-allowed; }
.pp-chatlog { flex: 1; overflow-y: auto; font: 13px/1.5 ui-monospace, Menlo, Consolas, monospace; padding: 6px; background: #0d111a; border-radius: 6px; border: 1px solid var(--pp-line); user-select: text; }
.pp-chatlog .sys { color: var(--pp-gold); }
.pp-chatlog b { color: #7aa7ff; font-weight: 500; }
.pp-chat form { margin-top: 8px; }
.pp-chat input { width: 100%; }
.pp-lobby-foot { display: flex; align-items: center; gap: 10px; }
.pp-status { flex: 1; color: var(--pp-dim); font-family: var(--pp-font); font-size: 17px; letter-spacing: .03em; }
.pp-status b { color: var(--pp-gold); font-size: 22px; }
.pp-ready { min-width: 160px; background: #3a1a1e; border-color: #7a3a40; }
.pp-ready.on { background: #1d3a24; border-color: #3f8a52; }

/* game */
.pp-game { position: absolute; inset: 0; }
.pp-canvas { position: absolute; inset: 0; width: 100%; height: 100%; display: block; cursor: crosshair; }
.pp-hud { position: absolute; inset: 0; pointer-events: none; font-family: var(--pp-font); }
.pp-hud button { pointer-events: auto; }
.pp-obj { position: absolute; top: 14px; left: 16px; font-size: 15px; letter-spacing: .02em; text-shadow: 0 2px 2px #000; max-width: 42%; }
.pp-obj-h { font-weight: 700; font-size: 13px; color: #fff; letter-spacing: .08em; }
.pp-obj .done { color: #7fd892; text-decoration: line-through; text-decoration-color: rgba(127, 216, 146, .5); }
.pp-obj .hot { color: var(--pp-gold); }
.pp-clock { position: absolute; top: 12px; left: 50%; transform: translateX(-50%); font-size: 26px; font-weight: 600; text-align: center; line-height: 1; text-shadow: 0 2px 3px #000; }
.pp-clock small { display: block; font-size: 11px; color: var(--pp-dim); letter-spacing: .1em; text-transform: uppercase; margin-top: 3px; }
.pp-clock.low { color: #ff8a8a; }
.pp-tracker { position: absolute; top: 12px; right: 14px; display: flex; gap: 6px; align-items: flex-end; padding: 6px 10px; background: rgba(10, 13, 20, .78); border: 1px solid var(--pp-line); border-radius: 8px; }
.pp-pip { display: flex; flex-direction: column; align-items: center; width: 22px; }
.pp-pip svg { width: 18px; height: 22px; }
.pp-pip i { font-style: normal; font-size: 12px; line-height: 1; font-weight: 700; color: #6fe08a; }
.pp-pip.captured svg { opacity: .45; }
.pp-pip.captured i { color: #ff5a5a; }
.pp-pip.hunter i { color: #ff5a5a; }
.pp-sep { width: 1px; align-self: stretch; background: var(--pp-line); margin: 0 2px; }
.pp-toasts { position: absolute; top: 70px; left: 50%; transform: translateX(-50%); display: flex; flex-direction: column; align-items: center; gap: 4px; }
.pp-toast { padding: 4px 12px; border-radius: 6px; background: rgba(10, 13, 20, .82); border-left: 3px solid var(--pp-blue); font-size: 15px; letter-spacing: .02em; animation: pp-in .25s ease-out; }
.pp-toast.good { border-color: var(--pp-green); }
.pp-toast.bad { border-color: var(--pp-red); color: #ffd2d2; }
@keyframes pp-in { from { opacity: 0; transform: translateY(-6px); } }
.pp-lockdown { position: absolute; top: 34%; left: 50%; transform: translateX(-50%); font-size: clamp(30px, 5vw, 52px); font-weight: 700; color: #ff3d3d; text-shadow: 0 0 18px rgba(255, 0, 0, .6), 0 3px 0 #000; text-align: center; letter-spacing: .03em; animation: pp-pulse 1s ease-in-out infinite; }
.pp-lockdown small { display: block; font-size: 16px; color: #ffd0d0; letter-spacing: .06em; }
@keyframes pp-pulse { 50% { opacity: .75; } }
.pp-banner { position: absolute; top: 22%; left: 50%; transform: translateX(-50%); padding: 8px 18px; border-radius: 8px; background: rgba(10, 13, 20, .8); border: 1px solid var(--pp-line); font-size: 20px; letter-spacing: .04em; white-space: nowrap; }
.pp-banner.bad { border-color: var(--pp-red); color: #ffd2d2; }
.pp-prompt { position: absolute; bottom: 120px; left: 50%; transform: translateX(-50%); padding: 6px 14px; border-radius: 8px; background: rgba(10, 13, 20, .85); border: 1px solid var(--pp-gold); font-size: 17px; letter-spacing: .03em; white-space: nowrap; }
.pp-minimap-wrap { position: absolute; left: 14px; bottom: 14px; padding: 6px; background: rgba(10, 13, 20, .82); border: 1px solid var(--pp-line); border-radius: 8px; display: flex; flex-direction: column; align-items: center; gap: 2px; }
.pp-minimap { width: 180px; height: 125px; display: block; }
.pp-minimap-wrap span { font-size: 12px; color: var(--pp-dim); letter-spacing: .08em; text-transform: uppercase; }
.pp-actionbar { position: absolute; bottom: 34px; left: 50%; transform: translateX(-50%); display: flex; align-items: center; gap: 12px; }
.pp-stamina { width: 240px; }
.pp-stamina label { font-size: 12px; letter-spacing: .08em; text-transform: uppercase; color: var(--pp-dim); display: flex; justify-content: space-between; margin-bottom: 3px; }
.pp-stamina > div { height: 10px; border-radius: 6px; background: rgba(10, 13, 20, .85); border: 1px solid var(--pp-line); overflow: hidden; }
.pp-stamina i { display: block; height: 100%; background: linear-gradient(90deg, #3fae5a, #9be27a); transition: width .1s linear; }
.pp-stamina.tired i { background: #a33; }
.pp-ability { position: relative; display: flex; align-items: center; gap: 10px; padding: 8px 14px; border-radius: 10px; border: 1px solid #5a2a30; color: var(--pp-text); font-family: var(--pp-font); overflow: hidden; cursor: pointer;
  background: linear-gradient(90deg, rgba(10, 13, 20, .9) calc(var(--cd) * 100%), rgba(90, 22, 30, .9) calc(var(--cd) * 100%)); }
.pp-ability.ready { border-color: #e05a5a; box-shadow: 0 0 16px rgba(224, 90, 90, .35); }
.pp-ability b { font-size: 17px; font-weight: 600; letter-spacing: .03em; }
.pp-ability small { font-size: 13px; color: var(--pp-dim); min-width: 36px; }
.pp-hint { font-size: 13px; color: var(--pp-dim); letter-spacing: .04em; text-shadow: 0 1px 2px #000; }
.pp-help { position: absolute; bottom: 8px; left: 50%; transform: translateX(-50%); font: 11px system-ui, sans-serif; color: #6b7590; white-space: nowrap; }
.pp-linkbtn { margin-left: 10px; border: 0; background: none; color: #9aa6c0; text-decoration: underline; cursor: pointer; font: inherit; }
.pp-end { position: absolute; inset: 0; display: grid; place-items: center; background: rgba(4, 5, 9, .72); backdrop-filter: blur(3px); animation: pp-in .4s ease-out; }
.pp-end-card { width: min(620px, 92%); padding: 22px 24px; border-radius: 12px; background: var(--pp-panel); border: 1px solid var(--pp-line); text-align: center; }
.pp-end-card h2 { margin: 0; font: 700 44px/1 var(--pp-font); letter-spacing: .03em; }
.pp-end-card.seekers h2 { color: #7fd892; }
.pp-end-card.hunters h2 { color: #ff6a6a; }
.pp-end-you { color: var(--pp-dim); margin: 6px 0 14px; }
.pp-end-card table { width: 100%; border-collapse: collapse; font-size: 13px; }
.pp-end-card th { text-align: left; color: var(--pp-dim); font-weight: 500; border-bottom: 1px solid var(--pp-line); padding: 4px 6px; font-family: var(--pp-font); letter-spacing: .05em; text-transform: uppercase; }
.pp-end-card td { text-align: left; padding: 4px 6px; border-bottom: 1px solid #1b2130; }
.pp-end-card tr.me td { color: var(--pp-gold); }
.pp-end-foot { margin: 12px 0 0; font-size: 12px; color: var(--pp-dim); }

@media (max-width: 860px) {
  .pp-lobby-grid { grid-template-columns: 1fr; overflow-y: auto; }
  .pp-panel { min-height: 200px; }
  .pp-obj { font-size: 13px; }
  .pp-minimap { width: 120px; height: 84px; }
  .pp-help { display: none; }
}
</style>
