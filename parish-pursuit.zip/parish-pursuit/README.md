# Parish Pursuit — *Sanctuary of Shadows* (base game)

Asymmetrical multiplayer hide-and-hunt: **Seekers** sneak through a candle-lit parish to expose the Cardinal's secret while **the clergy** (Father Dave, The Nun, The Bishop) hunt them down.

```
client/
  ParishPursuit.vue   ← drop-in Vue 3 component (menu, lobby, game, HUD, end screen)
  parish-core.js      ← shared rules engine: map, physics, abilities, bots, lobby/matchmaking hub
server/
  index.js            ← Node authoritative server (Express + Socket.IO), imports ../client/parish-core.js
  sim.js              ← headless bot-vs-bot balance runner
  smoke-test.js       ← end-to-end socket test (matchmaking → match → bot takeover)
```

The core has **zero dependencies** and runs in both places: authoritative on the server, and inside the browser for offline practice. One rules implementation, no drift.

## Quick start

```bash
# server
cd server && npm install && npm start          # :3000  (PORT, CORS_ORIGIN, STATIC_DIR env vars)
npm run smoke                                   # in a second terminal: full socket test
npm run sim -- 40 5 2                           # 40 bot matches, 5 seekers vs 2 hunters

# client (any Vue 3.3+ app)
npm install socket.io-client
cp client/ParishPursuit.vue client/parish-core.js src/components/
```

```vue
<script setup>
import ParishPursuit from './components/ParishPursuit.vue';
</script>

<template>
  <!-- online -->
  <ParishPursuit server-url="http://localhost:3000" height="100vh" @match-end="r => console.log(r.winner)" />
  <!-- or fully offline vs bots, no server -->
  <ParishPursuit offline height="100vh" />
</template>
```

Props: `server-url` (empty = same origin), `offline`, `player-name`, `height`. Event: `match-end` (winner, reason, per-player stats).
`socket.io-client` is lazy-loaded, so offline builds don't pay for it. If the server and Vite dev server share a machine, set `CORS_ORIGIN=http://localhost:5173`.

## How a match plays

| | Seekers | Hunters |
|---|---|---|
| Win | Steal the **Office Key** (Vestry) → opens the crypt · collect **6 of 8 evidence** (3 are in the Catacombs) · **Contact Police** at the Bell Tower → survive the **45s LOCKDOWN** | Jail every seeker at once, or reach **Morning Mass** (8:00 timer) |
| Move | WASD · **Shift** sprint (stamina) | Faster than walking, slower than sprinting |
| Act | Hold **E**: steal key, collect evidence, call police, pull the **holding-cell lever** to free everyone | Touch = capture → seeker is sent to the holding cell; hunter is locked for 2.5s ("Forced Confession") · hold **E** at the phone to cut the line (+6s back on the clock) |
| Ability | — | **Q / click**, aimed with the mouse |

Hunter abilities:
- **Father Dave — Corruption Spread** (40s): taints all evidence within 8 tiles for 45s. A seeker who collects tainted evidence is stunned and revealed. Seekers can spot the trap: tainted sparkles flicker red.
- **The Nun — The Nun's Pursuit** (18s): rosary tether projectile; on hit it pulls the seeker toward her and roots them.
- **The Bishop — The Bishop's Smoke** (24s): cloud at the cursor; seekers inside are slowed, nearly blind, and can't see through it. Hunters see clearly.

Hunters are frozen for the first 6s so seekers can scatter. Players who disconnect mid-match are taken over by a bot.

## Architecture notes

- **Authoritative server at 30 Hz.** Clients send only intent (`mx, my, sprint, interact, aim, abilitySeq`); the server simulates everything and sends each player their own snapshot. Snapshots are sent `volatile` so a slow connection drops stale frames instead of queueing them.
- **Server-side fog of war.** `Game.canSee()` uses grid ray-casting (walls and locked doors block; pews don't), smoke occlusion, and reveal timers. Players you can't see are **never sent**, so wall-hack clients get nothing.
- **Abilities are edge-triggered by a sequence number**, so a dropped packet can't eat a cast and a repeated packet can't double-cast.
- **Lobby/matchmaking** (`Hub`): Quick Play fills public rooms or opens one; private rooms use 4-letter codes. Roles are unique per hunter, compositions are validated (≥1 hunter, seekers ≥ hunters), all-ready triggers a countdown, the host can add/fill/kick bots or force-start. After a match everyone returns to the lobby.
- **Rendering**: a canvas with a pre-rendered 2.5D map, y-sorted characters drawn procedurally, and a light-map built from ray-cast vision polygons (your flashlight cone, teammates' torches, hunters' lanterns, candles). The light-map renders at ⅓ resolution and is upscaled — lights are soft, so it looks the same at ~9× lower fill cost.
- **Bots** use cached BFS distance fields. Seekers pick objectives, avoid evidence they suspect is tainted, rescue jailed friends, and flee to an *escape point they can reach before the hunter* (not just "away", which leads into dead ends). Hunters chase by sight, check last-seen positions, patrol objectives, defend the phone during lockdown, and use their abilities.

## Balance (bot vs bot, from `npm run sim`)

| Setup | Seekers win | Avg length |
|---|---|---|
| 3 seekers vs 1 hunter | ~97% | ~4.3 min |
| 5 seekers vs 2 hunters | ~33% | ~4.2 min |
| 4 seekers vs 2 hunters | ~15% | ~3.2 min |
| 6 seekers vs 3 hunters | ~0% | ~2 min |

"Fill with bots" builds **5 seekers vs 2 hunters**. A human seeker plays noticeably better than a seeker bot, so real matches skew toward the seekers. Every tunable lives in `CONFIG` at the top of `parish-core.js`: speeds, timers, cooldowns, evidence needed, vision ranges, and lockdown length.

## Known gaps / next steps

- **Client-side prediction**: the local player is interpolated, not predicted. That's fine on LAN or low ping, but above ~120ms you'll want input-sequence prediction with reconciliation. `moveEntity` is already shared, so the client can run it.
- **Reconnect into a running match**: currently a disconnect hands your character to a bot.
- **Touch controls, audio, character art/animation sheets**: all rendering is procedural canvas, so it's easy to swap in sprite sheets.
- **Scaling**: one process holds every room in memory. For horizontal scale, shard rooms by code behind a sticky load balancer.
